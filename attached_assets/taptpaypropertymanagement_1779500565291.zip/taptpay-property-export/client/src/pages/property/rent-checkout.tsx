import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Building2, CheckCircle2, XCircle, RefreshCw, Lock } from "lucide-react";
import { PT } from "@/lib/property-theme";

interface ResolvedInvoice {
  invoiceId: string;
  amountCents: number;
  dueAt: string;
  status: string;
  merchantName: string;
  propertyAddress: string;
  tenantName: string;
  coTenantsText?: string | null;
  alreadyPaid?: boolean;
}

function centsToDisplay(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

// ─── Already Paid screen ──────────────────────────────────────────────────────
function AlreadyPaidScreen({ amount }: { amount: number }) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center" style={{ background: PT.surface }}>
      <div className="w-20 h-20 rounded-full flex items-center justify-center mb-6" style={{ background: `${PT.success}18` }}>
        <CheckCircle2 size={40} style={{ color: PT.success }} />
      </div>
      <h1 className="text-2xl font-bold mb-2 lowercase" style={{ color: PT.navy }}>already paid</h1>
      <p className="text-base lowercase" style={{ color: PT.muted }}>
        this payment of {centsToDisplay(amount)} has already been received. no further action needed.
      </p>
    </div>
  );
}

// ─── Void / Not Found screen ──────────────────────────────────────────────────
function ErrorScreen({ message }: { message: string }) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center" style={{ background: PT.surface }}>
      <div className="w-20 h-20 rounded-full flex items-center justify-center mb-6" style={{ background: `${PT.danger}11` }}>
        <XCircle size={40} style={{ color: PT.danger }} />
      </div>
      <h1 className="text-xl font-bold mb-2 lowercase" style={{ color: PT.navy }}>link unavailable</h1>
      <p className="text-sm lowercase" style={{ color: PT.muted }}>{message}</p>
    </div>
  );
}

// ─── Success screen ───────────────────────────────────────────────────────────
function SuccessScreen({ amount, merchantName }: { amount: number; merchantName: string }) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center" style={{ background: PT.surface }}>
      <motion.div
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 400, damping: 22 }}
        className="w-24 h-24 rounded-full flex items-center justify-center mb-6"
        style={{ background: `${PT.success}18` }}
      >
        <CheckCircle2 size={48} style={{ color: PT.success }} />
      </motion.div>
      <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.25 }}>
        <h1 className="text-2xl font-bold mb-2 lowercase" style={{ color: PT.navy }}>payment received</h1>
        <p className="text-3xl font-bold tabular-nums mb-3" style={{ color: PT.success }}>{centsToDisplay(amount)}</p>
        <p className="text-sm lowercase" style={{ color: PT.muted }}>
          thank you. {merchantName} has been notified and a receipt has been emailed to you.
        </p>
      </motion.div>
    </div>
  );
}

// ─── Declined screen ──────────────────────────────────────────────────────────
function DeclinedScreen({ onRetry }: { onRetry: () => void }) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-6 text-center" style={{ background: PT.surface }}>
      <div className="w-20 h-20 rounded-full flex items-center justify-center mb-6" style={{ background: `${PT.danger}11` }}>
        <XCircle size={40} style={{ color: PT.danger }} />
      </div>
      <h1 className="text-xl font-bold mb-2 lowercase" style={{ color: PT.navy }}>payment declined</h1>
      <p className="text-sm mb-8 lowercase" style={{ color: PT.muted }}>
        your payment could not be processed. please check your card details and try again.
      </p>
      <motion.button
        whileTap={{ scale: 0.95 }}
        onClick={onRetry}
        className="px-8 py-3 rounded-full font-semibold lowercase"
        style={{ background: PT.navy, color: "#fff" }}
      >
        try again
      </motion.button>
    </div>
  );
}

// ─── Main checkout screen ─────────────────────────────────────────────────────
function CheckoutScreen({
  token,
  invoice,
  onSuccess,
  onDeclined,
}: {
  token: string;
  invoice: ResolvedInvoice;
  onSuccess: () => void;
  onDeclined: () => void;
}) {
  const [paying, setPaying] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handlePay = async () => {
    setPaying(true);
    setError(null);
    try {
      const res = await fetch("/api/checkout/pay", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
      });
      if (res.status === 429) {
        setError("too many attempts. please wait a moment and try again.");
        setPaying(false);
        return;
      }
      if (!res.ok) {
        const e = await res.json().catch(() => ({}));
        setError(e.message ?? "payment error. please try again.");
        setPaying(false);
        return;
      }
      const { hppUrl } = await res.json();
      // Redirect to Windcave HPP — all wallet/card payments go through here
      window.location.href = hppUrl;
    } catch {
      setError("network error. please check your connection and try again.");
      setPaying(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: PT.surface }}>
      {/* Navy header band */}
      <div className="px-6 pt-14 pb-8" style={{ background: PT.navy }}>
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: `${PT.sky}22` }}>
            <Building2 size={20} style={{ color: PT.sky }} />
          </div>
          <div>
            <p className="text-xs uppercase tracking-widest lowercase" style={{ color: PT.sky, letterSpacing: "0.18em" }}>rent payment</p>
            <p className="font-semibold text-sm lowercase" style={{ color: "#fff" }}>{invoice.merchantName}</p>
          </div>
        </div>

        {/* Amount */}
        <p className="text-xs uppercase tracking-widest mb-1 lowercase" style={{ color: `${PT.sky}aa`, letterSpacing: "0.2em" }}>amount due</p>
        <p
          className="font-bold tabular-nums"
          style={{ fontSize: "clamp(52px,14vw,72px)", lineHeight: 1, letterSpacing: "-2px", color: PT.sky }}
        >
          {centsToDisplay(invoice.amountCents)}
        </p>
      </div>

      {/* Details card */}
      <div className="flex-1 px-5 py-6 flex flex-col gap-4">
        <div className="rounded-2xl p-5" style={{ background: PT.card }}>
          <div className="flex flex-col gap-3">
            <div>
              <p className="text-[10px] uppercase tracking-widest mb-0.5 lowercase" style={{ color: PT.muted, letterSpacing: "0.15em" }}>property</p>
              <p className="text-sm font-semibold lowercase" style={{ color: PT.navy }}>{invoice.propertyAddress}</p>
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-widest mb-0.5 lowercase" style={{ color: PT.muted, letterSpacing: "0.15em" }}>tenant</p>
              <p className="text-sm font-semibold lowercase" style={{ color: PT.navy }}>{invoice.tenantName}</p>
              {invoice.coTenantsText && (
                <p className="text-xs mt-0.5 lowercase" style={{ color: PT.muted }}>{invoice.coTenantsText}</p>
              )}
            </div>
            <div>
              <p className="text-[10px] uppercase tracking-widest mb-0.5 lowercase" style={{ color: PT.muted, letterSpacing: "0.15em" }}>due</p>
              <p className="text-sm lowercase" style={{ color: PT.navy }}>
                {new Date(invoice.dueAt).toLocaleDateString("en-NZ", { day: "numeric", month: "long", year: "numeric" })}
              </p>
            </div>
          </div>
        </div>

        {error && (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-sm text-center lowercase px-2"
            style={{ color: PT.danger }}
          >
            {error}
          </motion.p>
        )}

        <motion.button
          whileTap={{ scale: 0.97 }}
          transition={{ type: "spring", stiffness: 500, damping: 28 }}
          onClick={handlePay}
          disabled={paying}
          className="w-full py-4 rounded-2xl font-bold text-base lowercase flex items-center justify-center gap-3"
          style={{ background: PT.navy, color: "#fff", opacity: paying ? 0.75 : 1 }}
        >
          {paying ? (
            <><RefreshCw size={18} className="animate-spin" /> redirecting to payment…</>
          ) : (
            <><Lock size={16} /> pay {centsToDisplay(invoice.amountCents)}</>
          )}
        </motion.button>

        <div className="flex items-center justify-center gap-2 mt-1">
          <Lock size={11} style={{ color: PT.muted }} />
          <p className="text-[11px] lowercase" style={{ color: PT.muted }}>
            secured by windcave · apple pay & google pay accepted
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── Page root ────────────────────────────────────────────────────────────────
export default function RentCheckout() {
  const [, params] = useRoute("/r/:token");
  const [location] = useLocation();
  const token = params?.token ?? "";

  const [state, setState] = useState<"loading" | "checkout" | "paying" | "success" | "declined" | "already_paid" | "error">("loading");
  const [invoice, setInvoice] = useState<ResolvedInvoice | null>(null);
  const [errorMsg, setErrorMsg] = useState("");

  const resolve = async () => {
    setState("loading");
    try {
      const res = await fetch(`/api/checkout/resolve/${token}`);
      if (res.status === 404 || res.status === 410) {
        const e = await res.json().catch(() => ({}));
        setErrorMsg(e.message ?? "This payment link is no longer valid.");
        setState("error");
        return;
      }
      if (!res.ok) { setState("error"); setErrorMsg("Unable to load payment details."); return; }
      const data: ResolvedInvoice = await res.json();
      if (data.alreadyPaid) { setInvoice(data); setState("already_paid"); return; }
      setInvoice(data);
      setState("checkout");
    } catch {
      setState("error");
      setErrorMsg("Network error. Please check your connection.");
    }
  };

  useEffect(() => {
    if (!token) return;
    // Detect return from Windcave HPP via ?result= query param
    const searchParams = new URLSearchParams(window.location.search);
    const result = searchParams.get("result");
    if (result === "approved") { setState("success"); resolve(); return; }
    if (result === "declined" || result === "cancelled") { setState("declined"); resolve(); return; }
    resolve();
  }, [token]);

  if (state === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: PT.surface }}>
        <RefreshCw size={28} className="animate-spin" style={{ color: PT.sky }} />
      </div>
    );
  }

  if (state === "already_paid") return <AlreadyPaidScreen amount={invoice?.amountCents ?? 0} />;
  if (state === "success") return <SuccessScreen amount={invoice?.amountCents ?? 0} merchantName={invoice?.merchantName ?? ""} />;
  if (state === "declined") return <DeclinedScreen onRetry={() => setState("checkout")} />;
  if (state === "error") return <ErrorScreen message={errorMsg} />;

  if (state === "checkout" && invoice) {
    return (
      <CheckoutScreen
        token={token}
        invoice={invoice}
        onSuccess={() => setState("success")}
        onDeclined={() => setState("declined")}
      />
    );
  }

  return null;
}
