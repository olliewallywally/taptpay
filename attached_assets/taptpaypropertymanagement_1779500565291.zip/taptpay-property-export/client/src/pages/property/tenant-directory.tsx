import { useState, useCallback, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import {
  Building2, Plus, Search, ChevronRight, X, Check, Edit3, Archive,
  Mail, Phone, Users, MapPin, Calendar, Clock, AlertCircle, MoreVertical,
  RefreshCw, Download, Upload,
} from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Switch } from "@/components/ui/switch";
import { getCurrentMerchantId } from "@/lib/auth";
import { PT } from "@/lib/property-theme";
import { useToast } from "@/hooks/use-toast";

// ─── Types ────────────────────────────────────────────────────────────────────
interface TenantProfile {
  id: string;
  merchantId: number;
  firstName: string;
  lastName: string;
  email?: string | null;
  phone?: string | null;
  propertyAddress: string;
  coTenantsText?: string | null;
  preferredChannel: "sms" | "email";
  status: "active" | "archived";
  archivedAt?: string | null;
  createdAt: string;
  updatedAt: string;
}

interface ActiveSchedule {
  id: string;
  amountCents: number;
  frequency: "weekly" | "fortnightly" | "monthly";
  deliveryChannel: "sms" | "email";
  startDate: string;
  endDate?: string | null;
  nextRunDate: string;
  pauseNextCycle: boolean;
  status: "active" | "paused" | "terminated";
}

interface TransactionEvent {
  id: string;
  eventType: string;
  payload: Record<string, unknown> | null;
  createdAt: string;
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function centsToDisplay(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

function relativeTime(iso: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.floor(h / 24);
  return `${d}d ago`;
}

function eventLabel(type: string) {
  const map: Record<string, string> = {
    Tenant_Created: "Tenant added",
    Tenant_Archived: "Tenant archived",
    Schedule_Created: "Recurring schedule created",
    Schedule_Paused: "Schedule paused for next cycle",
    Schedule_Resumed: "Schedule resumed",
    Schedule_Terminated: "Schedule terminated",
    Invoice_Generated: "Invoice generated",
    Invoice_Sent: "Invoice sent",
    Invoice_Voided: "Invoice voided",
    Payment_Success: "Payment received",
    Payment_Declined: "Payment declined",
    Payment_External: "Marked paid externally",
    Reminder_Sent: "Reminder sent",
  };
  return map[type] ?? type.replace(/_/g, " ").toLowerCase();
}

function frequencyLabel(f: string) {
  return f === "fortnightly" ? "every 2 weeks" : f;
}

// ─── Empty State ──────────────────────────────────────────────────────────────
function EmptyState({ onAdd }: { onAdd: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center py-24 px-8 text-center">
      <div
        className="w-20 h-20 rounded-2xl flex items-center justify-center mb-6"
        style={{ background: PT.card, border: `1.5px solid ${PT.sky}33` }}
      >
        <Building2 size={36} style={{ color: PT.sky, opacity: 0.5 }} />
      </div>
      <p className="font-semibold text-base mb-1 lowercase" style={{ color: PT.navy }}>
        no tenants yet
      </p>
      <p className="text-sm mb-8 max-w-xs lowercase" style={{ color: PT.muted }}>
        add your first tenant to start sending rent requests and tracking payments.
      </p>
      <motion.button
        onClick={onAdd}
        whileTap={{ scale: 0.94 }}
        transition={{ type: "spring", stiffness: 600, damping: 28 }}
        className="flex items-center gap-2 px-6 py-3 rounded-full text-sm font-semibold lowercase"
        style={{ background: PT.navy, color: "#fff" }}
      >
        <Plus size={15} />
        add your first tenant
      </motion.button>
      <a
        href="/tenant-import-template.csv"
        download
        className="mt-4 text-xs underline lowercase"
        style={{ color: PT.sky }}
      >
        download csv template
      </a>
    </div>
  );
}

// ─── Tenant List Row ──────────────────────────────────────────────────────────
function TenantRow({ tenant, onClick }: { tenant: TenantProfile; onClick: () => void }) {
  const isArchived = tenant.status === "archived";
  return (
    <motion.button
      onClick={onClick}
      whileTap={{ scale: 0.98 }}
      transition={{ type: "spring", stiffness: 500, damping: 30 }}
      className="w-full text-left"
    >
      <div
        className="flex items-center gap-4 px-5 py-4 mx-4 mb-2 rounded-2xl"
        style={{ background: PT.card, opacity: isArchived ? 0.55 : 1 }}
      >
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold"
          style={{ background: `${PT.sky}22`, color: PT.navy }}
        >
          {tenant.firstName[0]}{tenant.lastName[0]}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm truncate lowercase" style={{ color: PT.navy }}>
            {tenant.firstName} {tenant.lastName}
          </p>
          <p className="text-xs truncate mt-0.5 lowercase" style={{ color: PT.muted }}>
            {tenant.propertyAddress}
          </p>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
          {isArchived && (
            <span
              className="text-[10px] font-semibold px-2 py-0.5 rounded-full lowercase"
              style={{ background: `${PT.muted}22`, color: PT.muted }}
            >
              archived
            </span>
          )}
          <ChevronRight size={16} style={{ color: PT.sky }} />
        </div>
      </div>
    </motion.button>
  );
}

// ─── Add / Edit Tenant Form ───────────────────────────────────────────────────
interface TenantFormData {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  propertyAddress: string;
  coTenantsText: string;
  preferredChannel: "sms" | "email";
}

function TenantForm({
  initial,
  onSave,
  onCancel,
  saving,
}: {
  initial?: Partial<TenantFormData>;
  onSave: (d: TenantFormData) => void;
  onCancel: () => void;
  saving: boolean;
}) {
  const [form, setForm] = useState<TenantFormData>({
    firstName: initial?.firstName ?? "",
    lastName: initial?.lastName ?? "",
    email: initial?.email ?? "",
    phone: initial?.phone ?? "",
    propertyAddress: initial?.propertyAddress ?? "",
    coTenantsText: initial?.coTenantsText ?? "",
    preferredChannel: initial?.preferredChannel ?? "email",
  });

  const field = (key: keyof TenantFormData) => ({
    value: form[key] as string,
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setForm(f => ({ ...f, [key]: e.target.value })),
  });

  const inputCls = "w-full rounded-xl px-4 py-3 text-sm outline-none lowercase placeholder:lowercase";
  const inputStyle = { background: PT.surface, color: PT.navy, border: `1px solid ${PT.sky}33` };

  const valid = form.firstName.trim() && form.lastName.trim() && form.propertyAddress.trim() &&
    (form.email.trim() || form.phone.trim());

  return (
    <div className="flex flex-col gap-3">
      <div className="flex gap-2">
        <input className={inputCls} style={inputStyle} placeholder="first name" {...field("firstName")} />
        <input className={inputCls} style={inputStyle} placeholder="last name" {...field("lastName")} />
      </div>
      <input className={inputCls} style={inputStyle} placeholder="property address" {...field("propertyAddress")} />
      <input className={inputCls} style={inputStyle} placeholder="email" type="email" {...field("email")} />
      <input className={inputCls} style={inputStyle} placeholder="phone" type="tel" {...field("phone")} />
      <textarea
        className={`${inputCls} resize-none`}
        style={{ ...inputStyle, minHeight: 64 }}
        placeholder="co-tenants (optional)"
        {...field("coTenantsText")}
      />

      {/* Channel preference */}
      <div className="flex gap-2">
        {(["email", "sms"] as const).map(ch => (
          <button
            key={ch}
            type="button"
            onClick={() => setForm(f => ({ ...f, preferredChannel: ch }))}
            className="flex-1 py-2.5 rounded-xl text-sm font-semibold lowercase transition-all"
            style={
              form.preferredChannel === ch
                ? { background: PT.navy, color: "#fff" }
                : { background: PT.surface, color: PT.navy, border: `1px solid ${PT.sky}44` }
            }
          >
            {ch}
          </button>
        ))}
      </div>

      <div className="flex gap-2 mt-2">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 py-3 rounded-xl text-sm font-semibold lowercase"
          style={{ background: PT.surface, color: PT.muted }}
        >
          cancel
        </button>
        <motion.button
          type="button"
          onClick={() => valid && onSave(form)}
          whileTap={{ scale: 0.96 }}
          disabled={!valid || saving}
          className="flex-1 py-3 rounded-xl text-sm font-semibold lowercase flex items-center justify-center gap-2"
          style={{ background: valid && !saving ? PT.navy : `${PT.navy}66`, color: "#fff" }}
        >
          {saving ? <RefreshCw size={14} className="animate-spin" /> : <Check size={14} />}
          save
        </motion.button>
      </div>
    </div>
  );
}

// ─── Schedule Section (inside drawer) ────────────────────────────────────────
function ScheduleSection({ tenantId, merchantId }: { tenantId: string; merchantId: number }) {
  const queryClient = useQueryClient();
  const [adding, setAdding] = useState(false);
  const [scheduleForm, setScheduleForm] = useState({
    amountCents: "",
    frequency: "monthly" as "weekly" | "fortnightly" | "monthly",
    deliveryChannel: "email" as "sms" | "email",
    startDate: new Date().toISOString().split("T")[0],
  });

  const { data: schedules = [] } = useQuery<ActiveSchedule[]>({
    queryKey: ["/api/property/tenants", tenantId, "schedules"],
    queryFn: async () => {
      const r = await fetch(`/api/property/tenants/${tenantId}/schedules`, { credentials: "include" });
      if (!r.ok) throw new Error();
      return r.json();
    },
  });

  const pauseMutation = useMutation({
    mutationFn: async ({ id, pause }: { id: string; pause: boolean }) => {
      const r = await fetch(`/api/property/schedules/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ pauseNextCycle: pause }),
      });
      if (!r.ok) throw new Error();
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/property/tenants", tenantId, "schedules"] }),
  });

  const createMutation = useMutation({
    mutationFn: async () => {
      const dollars = parseFloat(scheduleForm.amountCents);
      const r = await fetch(`/api/property/tenants/${tenantId}/schedules`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          amountCents: Math.round(dollars * 100),
          frequency: scheduleForm.frequency,
          deliveryChannel: scheduleForm.deliveryChannel,
          startDate: new Date(scheduleForm.startDate).toISOString(),
          tenantProfileId: tenantId,
        }),
      });
      if (!r.ok) throw new Error();
    },
    onSuccess: () => {
      setAdding(false);
      queryClient.invalidateQueries({ queryKey: ["/api/property/tenants", tenantId, "schedules"] });
    },
  });

  const active = schedules.filter(s => s.status !== "terminated");
  const inputStyle = { background: PT.surface, color: PT.navy, border: `1px solid ${PT.sky}33` };

  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <p className="text-xs font-semibold uppercase tracking-widest lowercase" style={{ color: PT.navy, letterSpacing: "0.15em" }}>
          recurring schedule
        </p>
        {!adding && (
          <button onClick={() => setAdding(true)} style={{ color: PT.sky }} className="text-xs font-semibold lowercase">
            + add
          </button>
        )}
      </div>

      {adding && (
        <div className="rounded-2xl p-4 mb-3" style={{ background: PT.surface }}>
          <div className="flex flex-col gap-2">
            <input
              className="w-full rounded-xl px-4 py-2.5 text-sm outline-none"
              style={inputStyle}
              placeholder="amount (e.g. 1500)"
              type="number"
              value={scheduleForm.amountCents}
              onChange={e => setScheduleForm(f => ({ ...f, amountCents: e.target.value }))}
            />
            <div className="flex gap-1.5">
              {(["weekly", "fortnightly", "monthly"] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setScheduleForm(s => ({ ...s, frequency: f }))}
                  className="flex-1 py-2 rounded-xl text-[11px] font-semibold lowercase"
                  style={scheduleForm.frequency === f
                    ? { background: PT.navy, color: "#fff" }
                    : { background: PT.card, color: PT.navy, border: `1px solid ${PT.sky}33` }}
                >
                  {f}
                </button>
              ))}
            </div>
            <div className="flex gap-1.5">
              {(["email", "sms"] as const).map(ch => (
                <button
                  key={ch}
                  onClick={() => setScheduleForm(s => ({ ...s, deliveryChannel: ch }))}
                  className="flex-1 py-2 rounded-xl text-[11px] font-semibold lowercase"
                  style={scheduleForm.deliveryChannel === ch
                    ? { background: PT.navy, color: "#fff" }
                    : { background: PT.card, color: PT.navy, border: `1px solid ${PT.sky}33` }}
                >
                  {ch}
                </button>
              ))}
            </div>
            <input
              className="w-full rounded-xl px-4 py-2.5 text-sm outline-none"
              style={inputStyle}
              type="date"
              value={scheduleForm.startDate}
              onChange={e => setScheduleForm(f => ({ ...f, startDate: e.target.value }))}
            />
            <div className="flex gap-2 mt-1">
              <button onClick={() => setAdding(false)} className="flex-1 py-2.5 rounded-xl text-sm font-semibold lowercase" style={{ background: PT.card, color: PT.muted }}>cancel</button>
              <motion.button
                whileTap={{ scale: 0.96 }}
                onClick={() => createMutation.mutate()}
                disabled={!scheduleForm.amountCents || createMutation.isPending}
                className="flex-1 py-2.5 rounded-xl text-sm font-semibold lowercase flex items-center justify-center gap-1"
                style={{ background: PT.navy, color: "#fff" }}
              >
                {createMutation.isPending ? <RefreshCw size={12} className="animate-spin" /> : null}
                save
              </motion.button>
            </div>
          </div>
        </div>
      )}

      {active.length === 0 && !adding && (
        <p className="text-xs lowercase py-2" style={{ color: PT.muted }}>no active schedules</p>
      )}

      {active.map(s => (
        <div key={s.id} className="rounded-2xl p-4 mb-2" style={{ background: PT.surface }}>
          <div className="flex items-start justify-between">
            <div>
              <p className="font-semibold text-sm lowercase" style={{ color: PT.navy }}>
                {centsToDisplay(s.amountCents)} · {frequencyLabel(s.frequency)}
              </p>
              <p className="text-xs mt-0.5 lowercase" style={{ color: PT.muted }}>
                next: {new Date(s.nextRunDate).toLocaleDateString("en-NZ", { day: "numeric", month: "short" })}
                {" "}· via {s.deliveryChannel}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <p className="text-[10px] lowercase" style={{ color: PT.muted }}>pause next</p>
              <Switch
                checked={s.pauseNextCycle}
                onCheckedChange={v => pauseMutation.mutate({ id: s.id, pause: v })}
                style={{ transform: "scale(0.8)" }}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Activity Timeline ────────────────────────────────────────────────────────
function ActivityTimeline({ tenantId }: { tenantId: string }) {
  const { data: events = [], isLoading } = useQuery<TransactionEvent[]>({
    queryKey: ["/api/property/tenants", tenantId, "events"],
    queryFn: async () => {
      const r = await fetch(`/api/property/tenants/${tenantId}/events?limit=30`, { credentials: "include" });
      if (!r.ok) throw new Error();
      return r.json();
    },
  });

  if (isLoading) return <p className="text-xs lowercase py-2" style={{ color: PT.muted }}>loading…</p>;
  if (events.length === 0) return <p className="text-xs lowercase py-2" style={{ color: PT.muted }}>no activity yet</p>;

  return (
    <div className="flex flex-col gap-1.5">
      {events.map(e => (
        <div key={e.id} className="flex items-start gap-3">
          <div className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ background: PT.sky }} />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-medium lowercase" style={{ color: PT.navy }}>{eventLabel(e.eventType)}</p>
            <p className="text-[10px] lowercase" style={{ color: PT.muted }}>{relativeTime(e.createdAt)}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Tenant Drawer (profile + schedule + timeline) ─────────────────────────
function TenantDrawer({
  tenant,
  open,
  onClose,
  merchantId,
}: {
  tenant: TenantProfile | null;
  open: boolean;
  onClose: () => void;
  merchantId: number;
}) {
  const [editing, setEditing] = useState(false);
  const [archiveConfirm, setArchiveConfirm] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      const r = await fetch(`/api/property/tenants/${tenant!.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!r.ok) throw new Error("Update failed");
    },
    onSuccess: () => {
      setEditing(false);
      queryClient.invalidateQueries({ queryKey: ["/api/property/tenants"] });
      toast({ title: "tenant updated" });
    },
    onError: () => toast({ title: "update failed", variant: "destructive" }),
  });

  const archiveMutation = useMutation({
    mutationFn: async () => {
      const r = await fetch(`/api/property/tenants/${tenant!.id}/archive`, {
        method: "POST",
        credentials: "include",
      });
      if (!r.ok) throw new Error("Archive failed");
    },
    onSuccess: () => {
      setArchiveConfirm(false);
      onClose();
      queryClient.invalidateQueries({ queryKey: ["/api/property/tenants"] });
      toast({ title: "tenant archived" });
    },
    onError: () => toast({ title: "archive failed", variant: "destructive" }),
  });

  if (!tenant) return null;

  const isArchived = tenant.status === "archived";

  return (
    <Sheet open={open} onOpenChange={v => { if (!v) { onClose(); setEditing(false); setArchiveConfirm(false); } }}>
      <SheetContent
        side="right"
        className="p-0 overflow-y-auto"
        style={{ background: PT.card, width: "min(420px, 100vw)", maxWidth: "100vw", border: "none" }}
      >
        {/* Header band */}
        <div className="px-5 pt-12 pb-5 flex items-start justify-between" style={{ background: PT.navy }}>
          <div>
            <p className="text-xs uppercase tracking-widest mb-1 lowercase" style={{ color: PT.sky, letterSpacing: "0.2em" }}>tenant profile</p>
            <h2 className="text-xl font-bold lowercase" style={{ color: "#fff" }}>
              {tenant.firstName} {tenant.lastName}
            </h2>
            <p className="text-sm mt-0.5 lowercase" style={{ color: `${PT.sky}cc` }}>{tenant.propertyAddress}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-full flex items-center justify-center mt-1 flex-shrink-0" style={{ background: "rgba(255,255,255,0.1)" }}>
            <X size={14} color="#fff" />
          </button>
        </div>

        <div className="p-5 flex flex-col gap-6">
          {/* Profile section */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <p className="text-xs font-semibold uppercase tracking-widest lowercase" style={{ color: PT.navy, letterSpacing: "0.15em" }}>contact details</p>
              {!isArchived && (
                <button
                  onClick={() => setEditing(e => !e)}
                  className="flex items-center gap-1 text-xs font-semibold lowercase"
                  style={{ color: PT.sky }}
                >
                  <Edit3 size={11} />
                  {editing ? "cancel" : "edit"}
                </button>
              )}
            </div>

            <AnimatePresence mode="wait">
              {editing ? (
                <motion.div
                  key="form"
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
                  style={{ overflow: "hidden" }}
                >
                  <TenantForm
                    initial={{ ...tenant, email: tenant.email ?? "", phone: tenant.phone ?? "", coTenantsText: tenant.coTenantsText ?? "" }}
                    onSave={d => updateMutation.mutate(d as any)}
                    onCancel={() => setEditing(false)}
                    saving={updateMutation.isPending}
                  />
                </motion.div>
              ) : (
                <motion.div
                  key="view"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.15 }}
                  className="flex flex-col gap-2"
                >
                  {[
                    { icon: MapPin,  label: tenant.propertyAddress },
                    { icon: Mail,    label: tenant.email ?? "—" },
                    { icon: Phone,   label: tenant.phone ?? "—" },
                    { icon: Users,   label: tenant.coTenantsText ?? "no co-tenants" },
                  ].map(({ icon: Icon, label }) => (
                    <div key={label} className="flex items-center gap-3">
                      <Icon size={13} style={{ color: PT.sky, flexShrink: 0 }} />
                      <span className="text-sm lowercase" style={{ color: PT.navy }}>{label}</span>
                    </div>
                  ))}
                  <div className="flex items-center gap-3">
                    <Calendar size={13} style={{ color: PT.sky, flexShrink: 0 }} />
                    <span className="text-sm lowercase" style={{ color: PT.navy }}>prefers {tenant.preferredChannel}</span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Recurring schedule section */}
          {!isArchived && (
            <ScheduleSection tenantId={tenant.id} merchantId={merchantId} />
          )}

          {/* Activity timeline */}
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest mb-3 lowercase" style={{ color: PT.navy, letterSpacing: "0.15em" }}>
              activity
            </p>
            <ActivityTimeline tenantId={tenant.id} />
          </div>

          {/* Archive */}
          {!isArchived && (
            <div>
              {!archiveConfirm ? (
                <button
                  onClick={() => setArchiveConfirm(true)}
                  className="flex items-center gap-2 text-xs font-semibold lowercase py-3 px-4 rounded-xl w-full"
                  style={{ background: `${PT.danger}11`, color: PT.danger, border: `1px solid ${PT.danger}33` }}
                >
                  <Archive size={13} />
                  archive tenant
                </button>
              ) : (
                <div className="rounded-xl p-4" style={{ background: `${PT.danger}11`, border: `1px solid ${PT.danger}33` }}>
                  <p className="text-sm font-semibold mb-3 lowercase" style={{ color: PT.danger }}>
                    archive {tenant.firstName} {tenant.lastName}?
                  </p>
                  <p className="text-xs mb-4 lowercase" style={{ color: PT.muted }}>
                    their profile, invoices, and timeline stay in your archived view. any active schedules will be terminated.
                  </p>
                  <div className="flex gap-2">
                    <button onClick={() => setArchiveConfirm(false)} className="flex-1 py-2.5 rounded-xl text-sm font-semibold lowercase" style={{ background: PT.surface, color: PT.navy }}>cancel</button>
                    <motion.button
                      whileTap={{ scale: 0.96 }}
                      onClick={() => archiveMutation.mutate()}
                      disabled={archiveMutation.isPending}
                      className="flex-1 py-2.5 rounded-xl text-sm font-semibold lowercase flex items-center justify-center gap-1"
                      style={{ background: PT.danger, color: "#fff" }}
                    >
                      {archiveMutation.isPending ? <RefreshCw size={12} className="animate-spin" /> : <Archive size={12} />}
                      archive
                    </motion.button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </SheetContent>
    </Sheet>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function TenantDirectory() {
  const merchantId = getCurrentMerchantId();
  const [search, setSearch] = useState("");
  const [includeArchived, setIncludeArchived] = useState(false);
  const [selectedTenant, setSelectedTenant] = useState<TenantProfile | null>(null);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const [importing, setImporting] = useState(false);
  const csvInputRef = useRef<HTMLInputElement>(null);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: tenants = [], isLoading } = useQuery<TenantProfile[]>({
    queryKey: ["/api/property/tenants", { search, includeArchived }],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      if (includeArchived) params.set("includeArchived", "true");
      const r = await fetch(`/api/property/tenants?${params}`, { credentials: "include" });
      if (!r.ok) throw new Error();
      return r.json();
    },
    enabled: !!merchantId,
    staleTime: 30000,
  });

  const createMutation = useMutation({
    mutationFn: async (data: Record<string, unknown>) => {
      const r = await fetch("/api/property/tenants", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(data),
      });
      if (!r.ok) {
        const err = await r.json().catch(() => ({}));
        throw new Error(err.message ?? "Failed to create tenant");
      }
      return r.json();
    },
    onSuccess: () => {
      setAddOpen(false);
      queryClient.invalidateQueries({ queryKey: ["/api/property/tenants"] });
      toast({ title: "tenant added" });
    },
    onError: (err: Error) => toast({ title: err.message, variant: "destructive" }),
  });

  const handleCsvImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!csvInputRef.current) return;
    csvInputRef.current.value = "";
    if (!file) return;
    setImporting(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const r = await fetch("/api/property/tenants/import", { method: "POST", body: fd, credentials: "include" });
      const data = await r.json();
      if (!r.ok) throw new Error(data.message ?? "Import failed");
      queryClient.invalidateQueries({ queryKey: ["/api/property/tenants"] });
      const failMsg = data.failed?.length ? ` (${data.failed.length} row${data.failed.length > 1 ? "s" : ""} skipped)` : "";
      toast({ title: `imported ${data.imported} tenant${data.imported !== 1 ? "s" : ""}${failMsg}` });
    } catch (err: any) {
      toast({ title: err.message ?? "Import failed", variant: "destructive" });
    } finally {
      setImporting(false);
    }
  };

  const openTenant = useCallback((t: TenantProfile) => {
    setSelectedTenant(t);
    setDrawerOpen(true);
  }, []);

  const active = tenants.filter(t => t.status === "active");
  const archived = tenants.filter(t => t.status === "archived");
  const groups = [
    { label: "active", items: active },
    ...(includeArchived && archived.length > 0 ? [{ label: "archived", items: archived }] : []),
  ];

  return (
    <div className="min-h-screen pb-32" style={{ background: PT.surface }}>
      {/* Header band */}
      <div className="px-5 pt-12 pb-5" style={{ background: PT.navy }}>
        <div className="flex items-center justify-between mb-4">
          <p className="text-xl font-bold lowercase" style={{ color: "#fff" }}>tenants</p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIncludeArchived(v => !v)}
              className="text-xs font-semibold lowercase px-3 py-1.5 rounded-full"
              style={includeArchived
                ? { background: PT.sky, color: PT.navy }
                : { background: "rgba(255,255,255,0.1)", color: `${PT.sky}cc` }}
            >
              {includeArchived ? "hide archived" : "show archived"}
            </button>
            <a href="/tenant-import-template.csv" download title="download csv template">
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.1)" }}>
                <Download size={14} style={{ color: PT.sky }} />
              </div>
            </a>
            <button
              onClick={() => csvInputRef.current?.click()}
              disabled={importing}
              title="import tenants from csv"
              className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{ background: "rgba(255,255,255,0.1)" }}
            >
              {importing
                ? <RefreshCw size={14} className="animate-spin" style={{ color: PT.sky }} />
                : <Upload size={14} style={{ color: PT.sky }} />}
            </button>
            <input ref={csvInputRef} type="file" accept=".csv,text/csv" className="hidden" onChange={handleCsvImport} />
          </div>
        </div>

        {/* Search bar */}
        <div className="flex items-center gap-3 rounded-xl px-4 py-2.5" style={{ background: "rgba(255,255,255,0.1)" }}>
          <Search size={15} style={{ color: `${PT.sky}99`, flexShrink: 0 }} />
          <input
            className="flex-1 bg-transparent outline-none text-sm lowercase placeholder:lowercase"
            style={{ color: "#fff" }}
            placeholder="search by name or address…"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          {search && (
            <button onClick={() => setSearch("")}>
              <X size={13} style={{ color: `${PT.sky}99` }} />
            </button>
          )}
        </div>
      </div>

      {/* Count bar */}
      {!isLoading && tenants.length > 0 && (
        <div className="px-5 py-3 flex items-center justify-between">
          <p className="text-xs lowercase font-medium" style={{ color: PT.muted }}>
            {active.length} tenant{active.length !== 1 ? "s" : ""}
          </p>
        </div>
      )}

      {/* Body */}
      <div className="pt-2">
        {isLoading ? (
          <div className="flex flex-col gap-2 px-4 pt-2">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-[72px] rounded-2xl animate-pulse" style={{ background: PT.card }} />
            ))}
          </div>
        ) : tenants.length === 0 && !search ? (
          <EmptyState onAdd={() => setAddOpen(true)} />
        ) : tenants.length === 0 ? (
          <div className="flex flex-col items-center py-16 px-8 text-center">
            <AlertCircle size={32} style={{ color: PT.muted, marginBottom: 12 }} />
            <p className="text-sm lowercase" style={{ color: PT.muted }}>no tenants match "{search}"</p>
          </div>
        ) : (
          groups.map(({ label, items }) => items.length > 0 && (
            <div key={label}>
              {groups.length > 1 && (
                <p className="px-5 pb-2 pt-1 text-[10px] uppercase font-semibold tracking-widest lowercase" style={{ color: PT.muted, letterSpacing: "0.2em" }}>{label}</p>
              )}
              {items.map(t => (
                <TenantRow key={t.id} tenant={t} onClick={() => openTenant(t)} />
              ))}
            </div>
          ))
        )}
      </div>

      {/* Floating add button */}
      <AnimatePresence>
        {!addOpen && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ type: "spring", stiffness: 500, damping: 28 }}
            whileTap={{ scale: 0.9 }}
            onClick={() => setAddOpen(true)}
            className="fixed bottom-24 right-5 w-14 h-14 rounded-full flex items-center justify-center shadow-lg z-40"
            style={{ background: PT.sky, boxShadow: `0 4px 20px ${PT.sky}66` }}
          >
            <Plus size={22} style={{ color: PT.navy }} />
          </motion.button>
        )}
      </AnimatePresence>

      {/* Add tenant drawer */}
      <Sheet open={addOpen} onOpenChange={v => setAddOpen(v)}>
        <SheetContent
          side="right"
          className="p-0 overflow-y-auto"
          style={{ background: PT.card, width: "min(420px, 100vw)", maxWidth: "100vw", border: "none" }}
        >
          <div className="px-5 pt-12 pb-5" style={{ background: PT.navy }}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs uppercase tracking-widest mb-1 lowercase" style={{ color: PT.sky, letterSpacing: "0.2em" }}>new tenant</p>
                <h2 className="text-xl font-bold lowercase" style={{ color: "#fff" }}>add tenant</h2>
              </div>
              <button onClick={() => setAddOpen(false)} className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: "rgba(255,255,255,0.1)" }}>
                <X size={14} color="#fff" />
              </button>
            </div>
          </div>
          <div className="p-5">
            <TenantForm
              onSave={d => createMutation.mutate(d as any)}
              onCancel={() => setAddOpen(false)}
              saving={createMutation.isPending}
            />
          </div>
        </SheetContent>
      </Sheet>

      {/* Tenant profile drawer */}
      <TenantDrawer
        tenant={selectedTenant}
        open={drawerOpen}
        onClose={() => { setDrawerOpen(false); setTimeout(() => setSelectedTenant(null), 300); }}
        merchantId={merchantId!}
      />
    </div>
  );
}
