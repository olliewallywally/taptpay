import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Building2, Users, AlertTriangle, Clock, CheckCircle2, TrendingUp } from "lucide-react";
import { PT } from "@/lib/property-theme";

interface DashStats {
  totalTenants: number;
  activeSchedules: number;
  pendingInvoices: number;
  overdueInvoices: number;
  collectedThisMonth: number; // cents
  outstandingTotal: number;   // cents
}

interface RecentInvoice {
  id: string;
  tenantName: string;
  propertyAddress: string;
  amountCents: number;
  status: string;
  dueAt: string;
}

function cents(n: number) {
  return `$${(n / 100).toFixed(2)}`;
}

function statusColor(status: string) {
  if (status === "paid" || status === "paid_external") return PT.success;
  if (status === "overdue") return PT.danger;
  if (status === "dispatched") return PT.warning;
  return PT.muted;
}

function statusLabel(status: string) {
  if (status === "paid" || status === "paid_external") return "paid";
  if (status === "overdue") return "overdue";
  if (status === "dispatched") return "sent";
  if (status === "pending_dispatch") return "queued";
  if (status === "voided") return "voided";
  return status;
}

function StatCard({ icon: Icon, label, value, sub, accent }: {
  icon: any; label: string; value: string; sub?: string; accent?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl p-4 flex flex-col gap-1"
      style={{ background: PT.card }}
    >
      <div className="flex items-center gap-2 mb-1">
        <div className="w-7 h-7 rounded-full flex items-center justify-center" style={{ background: `${accent ?? PT.navy}18` }}>
          <Icon size={14} style={{ color: accent ?? PT.navy }} />
        </div>
        <p className="text-[10px] uppercase tracking-widest lowercase font-medium" style={{ color: PT.muted, letterSpacing: "0.15em" }}>
          {label}
        </p>
      </div>
      <p className="text-2xl font-bold tabular-nums" style={{ color: accent ?? PT.navy }}>{value}</p>
      {sub && <p className="text-xs lowercase" style={{ color: PT.muted }}>{sub}</p>}
    </motion.div>
  );
}

export default function PropertyDashboard() {
  const { data: tenants = [], isLoading: loadingTenants } = useQuery<any[]>({
    queryKey: ["/api/property/tenants"],
    queryFn: () => fetch("/api/property/tenants", { credentials: "include" }).then(r => r.json()),
    staleTime: 60000,
  });

  const { data: invoices = [], isLoading: loadingInvoices } = useQuery<RecentInvoice[]>({
    queryKey: ["/api/property/invoices"],
    queryFn: () => fetch("/api/property/invoices", { credentials: "include" }).then(r => r.json()),
    staleTime: 30000,
  });

  const isLoading = loadingTenants || loadingInvoices;

  // Derive stats from query data
  const activeTenants = (tenants as any[]).filter((t: any) => t.status === "active").length;
  const pendingInvoices = (invoices as any[]).filter((i: any) => ["pending_dispatch", "dispatched"].includes(i.status)).length;
  const overdueInvoices = (invoices as any[]).filter((i: any) => i.status === "overdue").length;
  const paidInvoices = (invoices as any[]).filter((i: any) => i.status === "paid" || i.status === "paid_external");
  const now = new Date();
  const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  const collectedThisMonth = paidInvoices
    .filter((i: any) => i.paidAt && new Date(i.paidAt) >= thisMonthStart)
    .reduce((sum: number, i: any) => sum + (i.amountCents ?? 0), 0);
  const outstandingTotal = (invoices as any[])
    .filter((i: any) => ["pending_dispatch", "dispatched", "overdue"].includes(i.status))
    .reduce((sum: number, i: any) => sum + (i.amountCents ?? 0), 0);

  const recent = [...(invoices as any[])]
    .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 8);

  return (
    <div className="min-h-screen pb-32" style={{ background: PT.surface }}>
      {/* Header */}
      <div className="px-5 pt-12 pb-6" style={{ background: PT.navy }}>
        <div className="flex items-center gap-3 mb-2">
          <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: `${PT.sky}22` }}>
            <Building2 size={18} style={{ color: PT.sky }} />
          </div>
          <p className="text-xl font-bold lowercase" style={{ color: "#fff" }}>property overview</p>
        </div>
        <p className="text-sm lowercase" style={{ color: `${PT.sky}99` }}>
          {new Date().toLocaleDateString("en-NZ", { weekday: "long", day: "numeric", month: "long" })}
        </p>
      </div>

      <div className="px-5 py-5 flex flex-col gap-4">
        {/* Stat grid */}
        {isLoading ? (
          <div className="grid grid-cols-2 gap-3">
            {[1,2,3,4].map(i => (
              <div key={i} className="h-24 rounded-2xl animate-pulse" style={{ background: PT.card }} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            <StatCard icon={Users} label="active tenants" value={String(activeTenants)} accent={PT.navy} />
            <StatCard icon={TrendingUp} label="collected this month" value={cents(collectedThisMonth)} accent={PT.success} />
            <StatCard
              icon={Clock}
              label="outstanding"
              value={cents(outstandingTotal)}
              sub={`${pendingInvoices} invoice${pendingInvoices !== 1 ? "s" : ""} pending`}
              accent={PT.warning}
            />
            <StatCard
              icon={AlertTriangle}
              label="overdue"
              value={String(overdueInvoices)}
              sub={overdueInvoices === 0 ? "all up to date" : `invoice${overdueInvoices !== 1 ? "s" : ""} overdue`}
              accent={overdueInvoices > 0 ? PT.danger : PT.success}
            />
          </div>
        )}

        {/* Recent invoices */}
        <div>
          <p className="text-xs uppercase tracking-widest lowercase mb-3 font-semibold" style={{ color: PT.muted, letterSpacing: "0.15em" }}>
            recent invoices
          </p>
          {isLoading ? (
            <div className="flex flex-col gap-2">
              {[1,2,3].map(i => (
                <div key={i} className="h-16 rounded-2xl animate-pulse" style={{ background: PT.card }} />
              ))}
            </div>
          ) : recent.length === 0 ? (
            <div className="rounded-2xl p-6 flex flex-col items-center gap-2" style={{ background: PT.card }}>
              <CheckCircle2 size={28} style={{ color: PT.muted }} />
              <p className="text-sm lowercase" style={{ color: PT.muted }}>no invoices yet</p>
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              {recent.map((inv: any) => (
                <motion.div
                  key={inv.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="rounded-2xl px-4 py-3 flex items-center justify-between"
                  style={{ background: PT.card }}
                >
                  <div className="flex flex-col gap-0.5 flex-1 min-w-0">
                    <p className="text-sm font-semibold lowercase truncate" style={{ color: PT.navy }}>
                      {inv.tenantName ?? "—"}
                    </p>
                    <p className="text-xs lowercase truncate" style={{ color: PT.muted }}>
                      {inv.propertyAddress ?? ""}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-0.5 ml-3 shrink-0">
                    <p className="text-sm font-bold tabular-nums" style={{ color: PT.navy }}>
                      {cents(inv.amountCents ?? 0)}
                    </p>
                    <p className="text-[10px] font-semibold uppercase tracking-wide lowercase" style={{ color: statusColor(inv.status) }}>
                      {statusLabel(inv.status)}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
