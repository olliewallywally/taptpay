// Design tokens for the property-management vertical.
// Extracted from the v2 terminal screenshot — use these everywhere
// so every property page feels visually consistent.

export const PT = {
  navy:    "#0A1F8E",   // deep cobalt — header band, primary CTA bg, nav pill
  navyDeep:"#08197A",   // slightly darker — active nav icon circle
  sky:     "#7DA3F4",   // light periwinkle — amount text, pill borders, FAB, accents
  surface: "#EFEFF1",   // light cool grey — page body background
  card:    "#FFFFFF",   // white — list cards, drawer panels
  muted:   "#9A9AA0",   // grey — placeholder / empty-state copy
  success: "#22C55E",   // green — paid status
  warning: "#F59E0B",   // amber — overdue status
  danger:  "#EF4444",   // red — destructive actions
} as const;
