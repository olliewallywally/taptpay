# TaptPay Property Management — Replit Implementation Guide

## What's in this package

All files needed to add the property management vertical to TaptPay. This covers:
- **Phase 1**: Schema, storage layer, backend routes, tenant directory UI, sector-aware nav, settings toggle
- **Phase 2**: Hosted checkout (public `/r/:token` page), Windcave HPP bridge, rent receipt PDF
- **Phase 3**: Cron automation engine (generate → dispatch → mark overdue)
- **Phase 4**: CSV import, property dashboard, enriched invoice list

---

## Files included

### New files (add these)
| File | Purpose |
|------|---------|
| `client/src/lib/property-theme.ts` | PT design token system — all new pages import from here |
| `client/src/pages/property/tenant-directory.tsx` | Main tenant CRUD UI with drawer, schedules, activity timeline |
| `client/src/pages/property/property-dashboard.tsx` | Stats overview (collected, overdue, outstanding) |
| `client/src/pages/property/rent-checkout.tsx` | Public `/r/:token` payment page — NO auth required |
| `client/public/tenant-import-template.csv` | CSV import template for bulk tenant upload |
| `server/property-cron.ts` | Three-pass cron engine: generate / dispatch / overdue |
| `server/property-routes-excerpt.ts` | All property API routes to paste into routes.ts |
| `server/property-storage-excerpt.ts` | All property storage methods to paste into storage.ts |

### Modified files (merge these changes)
| File | What changed |
|------|-------------|
| `shared/schema.ts` | New tables: tenantProfiles, activeSchedules, invoicesRentRequests, transactionEvents; `sector` + `timezone` columns on merchants; `invoiceId` on transactions |
| `server/routes.ts` | Property routes + Windcave invoice notification branch added |
| `server/storage.ts` | Property storage methods added to DatabaseStorage class |
| `server/windcave.ts` | `createRentPaymentSession()` function added |
| `server/pdf-generator.ts` | `generateRentReceiptPdf()` function added |
| `client/src/App.tsx` | Lazy imports + routes: `/property`, `/property/dashboard`, `/r/:token` |
| `client/src/components/bottom-navigation.tsx` | Sector-aware nav (retail vs propertyManagement modes) |
| `client/src/pages/settings.tsx` | Sector toggle + timezone selector added |

---

## Step-by-step Replit implementation

### Step 1: Schema changes (`shared/schema.ts`)

Add these imports at the top of the schema alongside existing ones:
```typescript
// Already present — ensure these are imported:
import { pgTable, text, integer, boolean, decimal, timestamp, jsonb, uuid } from "drizzle-orm/pg-core";
```

Add these 4 new tables after the existing table definitions:

```typescript
// ─── Property management ──────────────────────────────────────────────────────

export const tenantProfiles = pgTable("tenant_profiles", {
  id: uuid("id").primaryKey().defaultRandom(),
  merchantId: integer("merchant_id").notNull().references(() => merchants.id, { onDelete: "cascade" }),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email"),
  phone: text("phone"),
  propertyAddress: text("property_address").notNull(),
  coTenantsText: text("co_tenants_text"),
  preferredChannel: text("preferred_channel").default("email"),
  status: text("status").default("active").notNull(),
  archivedAt: timestamp("archived_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const activeSchedules = pgTable("active_schedules", {
  id: uuid("id").primaryKey().defaultRandom(),
  merchantId: integer("merchant_id").notNull().references(() => merchants.id, { onDelete: "cascade" }),
  tenantProfileId: uuid("tenant_profile_id").notNull().references(() => tenantProfiles.id, { onDelete: "cascade" }),
  amountCents: integer("amount_cents").notNull(),
  frequency: text("frequency").notNull(), // monthly | fortnightly | weekly
  startDate: timestamp("start_date").notNull(),
  nextRunDate: timestamp("next_run_date").notNull(),
  daysUntilDue: integer("days_until_due").default(7).notNull(),
  status: text("status").default("active").notNull(), // active | paused | terminated
  pauseNextCycle: boolean("pause_next_cycle").default(false),
  terminatedAt: timestamp("terminated_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const invoicesRentRequests = pgTable("invoices_rent_requests", {
  id: uuid("id").primaryKey().defaultRandom(),
  merchantId: integer("merchant_id").notNull().references(() => merchants.id, { onDelete: "cascade" }),
  tenantProfileId: uuid("tenant_profile_id").notNull().references(() => tenantProfiles.id),
  scheduleId: uuid("schedule_id").references(() => activeSchedules.id),
  amountCents: integer("amount_cents").notNull(),
  status: text("status").default("pending_dispatch").notNull(), // pending_dispatch | dispatched | paid | paid_external | overdue | voided
  token: text("token").notNull().unique(),
  deliveryChannel: text("delivery_channel").default("email"),
  dueAt: timestamp("due_at"),
  billingPeriodStart: timestamp("billing_period_start"),
  billingPeriodEnd: timestamp("billing_period_end"),
  windcaveSessionId: text("windcave_session_id"),
  paidAt: timestamp("paid_at"),
  overdueAt: timestamp("overdue_at"),
  voidedAt: timestamp("voided_at"),
  externalPaymentReference: text("external_payment_reference"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const transactionEvents = pgTable("transaction_events", {
  id: uuid("id").primaryKey().defaultRandom(),
  merchantId: integer("merchant_id").notNull(),
  tenantProfileId: uuid("tenant_profile_id"),
  scheduleId: uuid("schedule_id"),
  invoiceId: uuid("invoice_id"),
  eventType: text("event_type").notNull(),
  payload: jsonb("payload"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
```

Add these columns to the existing `merchants` table:
```typescript
sector: text("sector").default("retail"),      // "retail" | "propertyManagement"
timezone: text("timezone").default("Pacific/Auckland"),
```

Add this column to the existing `transactions` table:
```typescript
invoiceId: uuid("invoice_id"),
```

Add Zod schemas (after existing schemas):
```typescript
export const createTenantProfileSchema = z.object({
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  email: z.string().email().optional().or(z.literal("")),
  phone: z.string().optional(),
  propertyAddress: z.string().min(1),
  coTenantsText: z.string().optional(),
  preferredChannel: z.enum(["email", "sms"]).default("email"),
});
export const updateTenantProfileSchema = createTenantProfileSchema.partial();

export const createActiveScheduleSchema = z.object({
  tenantProfileId: z.string().uuid(),
  amountCents: z.number().int().min(1),
  frequency: z.enum(["monthly", "fortnightly", "weekly"]),
  startDate: z.coerce.date(),
  daysUntilDue: z.number().int().min(1).max(30).default(7),
});
export const updateActiveScheduleSchema = createActiveScheduleSchema.partial().extend({
  pauseNextCycle: z.boolean().optional(),
  status: z.enum(["active", "paused", "terminated"]).optional(),
});

export const createAdHocInvoiceSchema = z.object({
  tenantProfileId: z.string().uuid(),
  amountCents: z.number().int().min(1),
  dueAt: z.coerce.date().optional(),
  deliveryChannel: z.enum(["email", "sms"]).default("email"),
});
export const markInvoicePaidExternalSchema = z.object({
  externalPaymentReference: z.string().optional(),
});
export const updateMerchantTimezoneSchema = z.object({
  timezone: z.string().min(1),
});

export type TenantProfile = typeof tenantProfiles.$inferSelect;
export type InsertTenantProfile = typeof tenantProfiles.$inferInsert;
export type ActiveSchedule = typeof activeSchedules.$inferSelect;
export type InsertActiveSchedule = typeof activeSchedules.$inferInsert;
export type InvoiceRentRequest = typeof invoicesRentRequests.$inferSelect;
export type InsertInvoiceRentRequest = typeof invoicesRentRequests.$inferInsert;
export type TransactionEvent = typeof transactionEvents.$inferSelect;
export type InsertTransactionEvent = typeof transactionEvents.$inferInsert;
```

### Step 2: Run Drizzle migration

In Replit shell:
```bash
npx drizzle-kit push
```

### Step 3: Storage layer (`server/storage.ts`)

1. Import the new types at the top of storage.ts alongside existing imports:
```typescript
import {
  tenantProfiles, activeSchedules, invoicesRentRequests, transactionEvents,
  TenantProfile, InsertTenantProfile, ActiveSchedule, InsertActiveSchedule,
  InvoiceRentRequest, InsertInvoiceRentRequest, TransactionEvent, InsertTransactionEvent,
} from "@shared/schema";
```

2. Add these methods to the `IStorage` interface:
```typescript
createTenantProfile(data: InsertTenantProfile): Promise<TenantProfile>;
getTenantProfile(id: string): Promise<TenantProfile | undefined>;
getTenantProfilesByMerchant(merchantId: number, opts?: { search?: string; includeArchived?: boolean }): Promise<TenantProfile[]>;
updateTenantProfile(id: string, updates: Partial<InsertTenantProfile>): Promise<TenantProfile | undefined>;
archiveTenantProfile(id: string): Promise<TenantProfile | undefined>;
createActiveSchedule(data: InsertActiveSchedule): Promise<ActiveSchedule>;
getActiveSchedule(id: string): Promise<ActiveSchedule | undefined>;
getActiveSchedulesByTenant(tenantProfileId: string): Promise<ActiveSchedule[]>;
getActiveSchedulesByMerchant(merchantId: number): Promise<ActiveSchedule[]>;
updateActiveSchedule(id: string, updates: Partial<InsertActiveSchedule>): Promise<ActiveSchedule | undefined>;
terminateActiveSchedule(id: string): Promise<ActiveSchedule | undefined>;
getDueActiveSchedules(now: Date): Promise<ActiveSchedule[]>;
createInvoiceRentRequest(data: InsertInvoiceRentRequest): Promise<InvoiceRentRequest>;
getInvoiceRentRequest(id: string): Promise<InvoiceRentRequest | undefined>;
getInvoiceRentRequestByToken(token: string): Promise<InvoiceRentRequest | undefined>;
getInvoiceRentRequestsByMerchant(merchantId: number, opts?: { status?: string; tenantProfileId?: string }): Promise<InvoiceRentRequest[]>;
updateInvoiceRentRequest(id: string, updates: Partial<InvoiceRentRequest>): Promise<InvoiceRentRequest | undefined>;
getInvoiceRentRequestByWindcaveSessionId(sessionId: string): Promise<InvoiceRentRequest | undefined>;
getPendingDispatchInvoices(): Promise<InvoiceRentRequest[]>;
getOverdueEligibleInvoices(now: Date): Promise<InvoiceRentRequest[]>;
logTransactionEvent(data: InsertTransactionEvent): Promise<TransactionEvent>;
getTransactionEventsByTenant(tenantProfileId: string, limit?: number): Promise<TransactionEvent[]>;
getTransactionEventsByInvoice(invoiceId: string): Promise<TransactionEvent[]>;
```

3. Copy the full implementation from `server/property-storage-excerpt.ts` into the `DatabaseStorage` class.

### Step 4: Backend routes (`server/routes.ts`)

1. Add these imports near the top of routes.ts:
```typescript
import {
  createTenantProfileSchema, updateTenantProfileSchema,
  createActiveScheduleSchema, updateActiveScheduleSchema,
  createAdHocInvoiceSchema, markInvoicePaidExternalSchema,
  updateMerchantTimezoneSchema,
} from "@shared/schema";
import { generateRentReceiptPdf } from "./pdf-generator";
import { createRentPaymentSession } from "./windcave";
```

2. Add multer for CSV upload near other middleware:
```typescript
import multer from "multer";
const csvUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 2 * 1024 * 1024 } });
```

3. Copy all routes from `server/property-routes-excerpt.ts` and paste them just before the final `const httpServer = createServer(app); return httpServer;` lines.

4. Inside the Windcave notification handler (`/api/windcave/notification`), add the invoice branch. After the `const transaction = await storage.getTransactionByWindcaveSessionId(sessionId);` line, add:
```typescript
// ── Property management: invoice-linked session ──────────────────────
if (!transaction) {
  const invoice = await storage.getInvoiceRentRequestByWindcaveSessionId(sessionId);
  // ... (see property-routes-excerpt.ts lines 1–138 for the full handler)
}
```

### Step 5: Windcave (`server/windcave.ts`)

Add `createRentPaymentSession()` — see the full `windcave.ts` file included, or add this function:

```typescript
export async function createRentPaymentSession(
  xId: string,
  amount: string,
  merchantRef: string,
  customerEmail: string | undefined,
  baseUrl: string,
  callbackBase: string,
) {
  // Creates a Windcave HPP session for a rent invoice.
  // callbackBase is the /r/:token URL — Windcave appends ?result=approved|declined|cancelled
  const successUrl = `${callbackBase}?result=approved`;
  const cancelUrl  = `${callbackBase}?result=cancelled`;
  const failUrl    = `${callbackBase}?result=declined`;
  // ... rest of implementation mirrors createWindcaveSession but uses the above URLs
}
```

### Step 6: Frontend — new routes in App.tsx

Add lazy imports:
```typescript
const TenantDirectory  = lazy(() => import("@/pages/property/tenant-directory"));
const RentCheckout     = lazy(() => import("@/pages/property/rent-checkout"));
const PropertyDashboard = lazy(() => import("@/pages/property/property-dashboard"));
```

Add routes inside `<Switch>`:
```tsx
<Route path="/property">
  <ProtectedRoute><TenantDirectory /></ProtectedRoute>
</Route>
<Route path="/property/dashboard">
  <ProtectedRoute><PropertyDashboard /></ProtectedRoute>
</Route>
{/* Public — no auth */}
<Route path="/r/:token" component={RentCheckout} />
```

### Step 7: Cron setup

`server/property-cron.ts` is self-contained. Register the endpoint in routes.ts (included in property-routes-excerpt.ts):
```
POST /api/internal/cron
Header: x-cron-secret: <CRON_SECRET>
```

Set `CRON_SECRET` env var in Replit Secrets, then call this endpoint hourly via Render Cron Job, GitHub Actions, or an external cron service like cron-job.org.

### Step 8: Environment variables needed

Add these to Replit Secrets:
```
CRON_SECRET=<random 32+ char string>
# Windcave (for live rent payments — leave unset to use simulation mode):
WINDCAVE_USERNAME=...
WINDCAVE_API_KEY=...
WINDCAVE_ENDPOINT=https://uat.windcave.com/api/v1
```

---

## Design token reference

All new property UI uses `PT` from `client/src/lib/property-theme.ts`:

```typescript
export const PT = {
  navy:     "#0A1F8E",   // headers, primary CTA, nav background
  navyDeep: "#08197A",   // active states
  sky:      "#7DA3F4",   // amounts, accents, icon tints
  surface:  "#EFEFF1",   // page background
  card:     "#FFFFFF",   // card / drawer background
  muted:    "#9A9AA0",   // secondary copy
  success:  "#22C55E",
  warning:  "#F59E0B",
  danger:   "#EF4444",
}
```

---

## Testing checklist

- [ ] `npx drizzle-kit push` runs without errors
- [ ] Settings → sector toggle switches nav between retail and property modes
- [ ] Tenant directory: create, edit, archive a tenant
- [ ] Schedule: create monthly schedule, verify nextRunDate is set
- [ ] Ad-hoc invoice: create → status is `pending_dispatch`
- [ ] Cron: POST `/api/internal/cron` with correct secret → check generate/dispatch/overdue counts
- [ ] Public checkout: visit `/r/<token>` — see tenant name, amount, Pay Now button
- [ ] Windcave sim: clicking Pay Now in sim mode redirects to `?result=approved`
- [ ] Property dashboard: stats cards and recent invoices list render
