  // ──────────────────────────────────────────────────────────────────────────
  // Property management vertical
  // ──────────────────────────────────────────────────────────────────────────

  async createTenantProfile(data: InsertTenantProfile): Promise<TenantProfile> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db.insert(tenantProfiles).values(data).returning();
    return result[0];
  }

  async getTenantProfile(id: string): Promise<TenantProfile | undefined> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db.select().from(tenantProfiles).where(eq(tenantProfiles.id, id)).limit(1);
    return result[0];
  }

  async getTenantProfilesByMerchant(
    merchantId: number,
    opts: { search?: string; includeArchived?: boolean } = {},
  ): Promise<TenantProfile[]> {
    if (!this.db) throw new Error('Database not available');
    const conditions = [eq(tenantProfiles.merchantId, merchantId)];
    if (!opts.includeArchived) conditions.push(eq(tenantProfiles.status, "active"));
    const search = opts.search?.trim();
    if (search) {
      const pattern = `%${search}%`;
      const term = or(
        ilike(tenantProfiles.firstName, pattern),
        ilike(tenantProfiles.lastName, pattern),
        ilike(tenantProfiles.propertyAddress, pattern),
        ilike(tenantProfiles.email, pattern),
      );
      if (term) conditions.push(term);
    }
    return await this.db
      .select()
      .from(tenantProfiles)
      .where(and(...conditions))
      .orderBy(desc(tenantProfiles.createdAt));
  }

  async updateTenantProfile(id: string, updates: Partial<InsertTenantProfile>): Promise<TenantProfile | undefined> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db
      .update(tenantProfiles)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(tenantProfiles.id, id))
      .returning();
    return result[0];
  }

  async archiveTenantProfile(id: string): Promise<TenantProfile | undefined> {
    if (!this.db) throw new Error('Database not available');
    const now = new Date();
    const profileResult = await this.db
      .update(tenantProfiles)
      .set({ status: "archived", archivedAt: now, updatedAt: now })
      .where(eq(tenantProfiles.id, id))
      .returning();
    // Cascade: terminate any non-terminated schedules for this tenant
    await this.db
      .update(activeSchedules)
      .set({ status: "terminated", terminatedAt: now, updatedAt: now })
      .where(and(eq(activeSchedules.tenantProfileId, id), sql`${activeSchedules.status} <> 'terminated'`));
    return profileResult[0];
  }

  async createActiveSchedule(data: InsertActiveSchedule): Promise<ActiveSchedule> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db.insert(activeSchedules).values(data).returning();
    return result[0];
  }

  async getActiveSchedule(id: string): Promise<ActiveSchedule | undefined> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db.select().from(activeSchedules).where(eq(activeSchedules.id, id)).limit(1);
    return result[0];
  }

  async getActiveSchedulesByMerchant(merchantId: number): Promise<ActiveSchedule[]> {
    if (!this.db) throw new Error('Database not available');
    return await this.db.select().from(activeSchedules).where(eq(activeSchedules.merchantId, merchantId));
  }

  async getActiveSchedulesByTenant(tenantProfileId: string): Promise<ActiveSchedule[]> {
    if (!this.db) throw new Error('Database not available');
    return await this.db.select().from(activeSchedules).where(eq(activeSchedules.tenantProfileId, tenantProfileId));
  }

  async updateActiveSchedule(id: string, updates: Partial<InsertActiveSchedule>): Promise<ActiveSchedule | undefined> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db
      .update(activeSchedules)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(activeSchedules.id, id))
      .returning();
    return result[0];
  }

  async terminateActiveSchedule(id: string): Promise<ActiveSchedule | undefined> {
    return this.updateActiveSchedule(id, { status: "terminated", terminatedAt: new Date() } as Partial<InsertActiveSchedule>);
  }

  async getDueActiveSchedules(now: Date): Promise<ActiveSchedule[]> {
    if (!this.db) throw new Error('Database not available');
    return await this.db
      .select()
      .from(activeSchedules)
      .where(and(eq(activeSchedules.status, "active"), lte(activeSchedules.nextRunDate, now)));
  }

  async createInvoiceRentRequest(data: InsertInvoiceRentRequest): Promise<InvoiceRentRequest> {
    if (!this.db) throw new Error('Database not available');
    // Idempotent insert when (scheduleId, billingPeriodStart) is provided
    if (data.scheduleId && data.billingPeriodStart) {
      const existing = await this.db
        .select()
        .from(invoicesRentRequests)
        .where(and(
          eq(invoicesRentRequests.scheduleId, data.scheduleId),
          eq(invoicesRentRequests.billingPeriodStart, data.billingPeriodStart as Date),
        ))
        .limit(1);
      if (existing[0]) return existing[0];
    }
    const result = await this.db.insert(invoicesRentRequests).values(data).returning();
    return result[0];
  }

  async getInvoiceRentRequest(id: string): Promise<InvoiceRentRequest | undefined> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db.select().from(invoicesRentRequests).where(eq(invoicesRentRequests.id, id)).limit(1);
    return result[0];
  }

  async getInvoiceRentRequestByToken(token: string): Promise<InvoiceRentRequest | undefined> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db.select().from(invoicesRentRequests).where(eq(invoicesRentRequests.token, token)).limit(1);
    return result[0];
  }

  async getInvoiceRentRequestsByMerchant(
    merchantId: number,
    opts: { status?: string; tenantProfileId?: string } = {},
  ): Promise<InvoiceRentRequest[]> {
    if (!this.db) throw new Error('Database not available');
    const conditions = [eq(invoicesRentRequests.merchantId, merchantId)];
    if (opts.status) conditions.push(eq(invoicesRentRequests.status, opts.status));
    if (opts.tenantProfileId) conditions.push(eq(invoicesRentRequests.tenantProfileId, opts.tenantProfileId));
    return await this.db
      .select()
      .from(invoicesRentRequests)
      .where(and(...conditions))
      .orderBy(desc(invoicesRentRequests.createdAt));
  }

  async updateInvoiceRentRequest(id: string, updates: Partial<InvoiceRentRequest>): Promise<InvoiceRentRequest | undefined> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db
      .update(invoicesRentRequests)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(invoicesRentRequests.id, id))
      .returning();
    return result[0];
  }

  async logTransactionEvent(data: InsertTransactionEvent): Promise<TransactionEvent> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db.insert(transactionEvents).values(data).returning();
    return result[0];
  }

  async getTransactionEventsByTenant(tenantProfileId: string, limit = 100): Promise<TransactionEvent[]> {
    if (!this.db) throw new Error('Database not available');
    return await this.db
      .select()
      .from(transactionEvents)
      .where(eq(transactionEvents.tenantProfileId, tenantProfileId))
      .orderBy(desc(transactionEvents.createdAt))
      .limit(limit);
  }

  async getTransactionEventsByInvoice(invoiceId: string): Promise<TransactionEvent[]> {
    if (!this.db) throw new Error('Database not available');
    return await this.db
      .select()
      .from(transactionEvents)
      .where(eq(transactionEvents.invoiceId, invoiceId))
      .orderBy(desc(transactionEvents.createdAt));
  }

  async getInvoiceRentRequestByWindcaveSessionId(sessionId: string): Promise<InvoiceRentRequest | undefined> {
    if (!this.db) throw new Error('Database not available');
    const result = await this.db
      .select()
      .from(invoicesRentRequests)
      .where(eq(invoicesRentRequests.windcaveSessionId, sessionId))
      .limit(1);
    return result[0];
  }

  async getPendingDispatchInvoices(): Promise<InvoiceRentRequest[]> {
    if (!this.db) throw new Error('Database not available');
    return await this.db
      .select()
      .from(invoicesRentRequests)
      .where(eq(invoicesRentRequests.status, "pending_dispatch"))
      .orderBy(invoicesRentRequests.createdAt);
  }

  async getOverdueEligibleInvoices(now: Date): Promise<InvoiceRentRequest[]> {
    if (!this.db) throw new Error('Database not available');
    return await this.db
      .select()
      .from(invoicesRentRequests)
      .where(and(eq(invoicesRentRequests.status, "dispatched"), lte(invoicesRentRequests.dueAt, now)));
  }

