  // Serve static uploads
  app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

  // ===========================================================================
  // HOSTED CHECKOUT — Phase 2  (/r/:token flow)
  // ===========================================================================

  // Per-token in-memory rate limiter (10 req/min per invoice token)
  const tokenRateMap = new Map<string, { count: number; windowStart: number }>();
  function tokenRateLimit(token: string): boolean {
    const now = Date.now();
    const window = 60_000;
    const limit = 10;
    const entry = tokenRateMap.get(token);
    if (!entry || now - entry.windowStart > window) {
      tokenRateMap.set(token, { count: 1, windowStart: now });
      return true;
    }
    if (entry.count >= limit) return false;
    entry.count++;
    return true;
  }
  // Evict stale entries every 5 minutes to prevent memory leak
  setInterval(() => {
    const cutoff = Date.now() - 120_000;
    tokenRateMap.forEach((v, k) => { if (v.windowStart < cutoff) tokenRateMap.delete(k); });
  }, 300_000);

  // Resolve invoice token — public, unauthenticated
  // Returns invoice + merchant name + tenant names needed to render the checkout page
  app.get("/api/checkout/resolve/:token", async (req, res) => {
    try {
      const { token } = req.params;
      if (!tokenRateLimit(token)) return res.status(429).json({ message: "Too many requests" });

      const invoice = await storage.getInvoiceRentRequestByToken(token);
      if (!invoice) return res.status(404).json({ message: "Payment link not found" });
      if (invoice.status === "voided") return res.status(410).json({ message: "This payment link has been voided" });
      if (invoice.status === "paid" || invoice.status === "paid_external") {
        return res.status(200).json({ alreadyPaid: true, amountCents: invoice.amountCents });
      }

      const merchant = await storage.getMerchant(invoice.merchantId);
      const tenant = await storage.getTenantProfile(invoice.tenantProfileId);
      if (!merchant || !tenant) return res.status(404).json({ message: "Payment details unavailable" });

      res.json({
        invoiceId: invoice.id,
        amountCents: invoice.amountCents,
        dueAt: invoice.dueAt,
        status: invoice.status,
        merchantName: merchant.businessName || merchant.name,
        propertyAddress: tenant.propertyAddress,
        tenantName: `${tenant.firstName} ${tenant.lastName}`,
        coTenantsText: tenant.coTenantsText ?? null,
      });
    } catch (error) {
      console.error("[CHECKOUT_RESOLVE]", error);
      res.status(500).json({ message: "Failed to load payment details" });
    }
  });

  // Create Windcave HPP session for a rent invoice — public, unauthenticated
  app.post("/api/checkout/pay", async (req, res) => {
    try {
      const { token } = req.body as { token?: string };
      if (!token) return res.status(400).json({ message: "token required" });
      if (!tokenRateLimit(token)) return res.status(429).json({ message: "Too many requests" });

      const invoice = await storage.getInvoiceRentRequestByToken(token);
      if (!invoice) return res.status(404).json({ message: "Payment link not found" });
      if (["voided", "paid", "paid_external"].includes(invoice.status)) {
        return res.status(409).json({ message: "Invoice is not payable" });
      }

      const merchant = await storage.getMerchant(invoice.merchantId);
      const tenant = await storage.getTenantProfile(invoice.tenantProfileId);
      if (!merchant || !tenant) return res.status(500).json({ message: "Invoice data unavailable" });

      const baseUrl = getBaseUrl(req);
      const amountStr = (invoice.amountCents / 100).toFixed(2);
      const merchantRef = `RENT-${invoice.id.slice(0, 8).toUpperCase()}`;
      const xId = crypto.randomBytes(16).toString("hex");
      // Callback URL takes the tenant back to the checkout page after HPP
      const callbackBase = `${baseUrl}/r/${token}`;

      let sessionResult;
      if (isWindcaveConfigured()) {
        sessionResult = await createRentPaymentSession(xId, amountStr, merchantRef, tenant.email ?? undefined, baseUrl, callbackBase);
      } else {
        sessionResult = simulateCreateSession(merchantRef, baseUrl);
      }

      if (!sessionResult.success || !sessionResult.hppUrl) {
        console.error("[CHECKOUT_PAY] Windcave session failed:", sessionResult.error);
        return res.status(502).json({ message: "Payment gateway error. Please try again." });
      }

      // Persist sessionId so the notification handler can find this invoice
      await storage.updateInvoiceRentRequest(invoice.id, {
        windcaveSessionId: sessionResult.sessionId,
      } as any);

      res.json({ hppUrl: sessionResult.hppUrl });
    } catch (error) {
      console.error("[CHECKOUT_PAY]", error);
      res.status(500).json({ message: "Failed to initiate payment" });
    }
  });

  // ===========================================================================
  // PROPERTY MANAGEMENT VERTICAL — Phase 1
  // ===========================================================================

  // Helper: generate a high-entropy url-safe base64 token (≥128 bits = 16 bytes)
  function generateInvoiceToken(): string {
    return crypto.randomBytes(20).toString("base64url");
  }

  // Helper: next run date calculation for schedules
  function computeNextRunDate(from: Date, frequency: string): Date {
    const d = new Date(from);
    if (frequency === "weekly")      d.setDate(d.getDate() + 7);
    else if (frequency === "fortnightly") d.setDate(d.getDate() + 14);
    else { // monthly
      d.setMonth(d.getMonth() + 1);
    }
    return d;
  }

  // ─── Tenant Profiles ───────────────────────────────────────────────────────

  // List tenants for authenticated merchant
  app.get("/api/property/tenants", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const search = typeof req.query.search === "string" ? req.query.search : undefined;
      const includeArchived = req.query.includeArchived === "true";
      const tenants = await storage.getTenantProfilesByMerchant(merchantId, { search, includeArchived });
      res.json(tenants);
    } catch (error) {
      console.error("Error listing tenants:", error);
      res.status(500).json({ message: "Failed to fetch tenants" });
    }
  });

  // Create tenant
  app.post("/api/property/tenants", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const data = createTenantProfileSchema.parse(req.body);
      const tenant = await storage.createTenantProfile({ ...data, merchantId } as any);
      await storage.logTransactionEvent({
        merchantId,
        tenantProfileId: tenant.id,
        eventType: "Tenant_Created",
        payload: { firstName: tenant.firstName, lastName: tenant.lastName, propertyAddress: tenant.propertyAddress },
      } as any);
      res.status(201).json(tenant);
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ message: "Validation error", errors: error.errors });
      console.error("Error creating tenant:", error);
      res.status(500).json({ message: "Failed to create tenant" });
    }
  });

  // Get single tenant
  app.get("/api/property/tenants/:id", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const tenant = await storage.getTenantProfile(req.params.id);
      if (!tenant) return res.status(404).json({ message: "Tenant not found" });
      if (!checkMerchantOwnership(req, tenant.merchantId)) return res.status(403).json({ message: "Access denied" });
      res.json(tenant);
    } catch (error) {
      console.error("Error fetching tenant:", error);
      res.status(500).json({ message: "Failed to fetch tenant" });
    }
  });

  // Update tenant
  app.put("/api/property/tenants/:id", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const existing = await storage.getTenantProfile(req.params.id);
      if (!existing) return res.status(404).json({ message: "Tenant not found" });
      if (!checkMerchantOwnership(req, existing.merchantId)) return res.status(403).json({ message: "Access denied" });
      const data = updateTenantProfileSchema.parse(req.body);
      const tenant = await storage.updateTenantProfile(req.params.id, data as any);
      res.json(tenant);
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ message: "Validation error", errors: error.errors });
      console.error("Error updating tenant:", error);
      res.status(500).json({ message: "Failed to update tenant" });
    }
  });

  // Archive tenant
  app.post("/api/property/tenants/:id/archive", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const existing = await storage.getTenantProfile(req.params.id);
      if (!existing) return res.status(404).json({ message: "Tenant not found" });
      if (!checkMerchantOwnership(req, existing.merchantId)) return res.status(403).json({ message: "Access denied" });
      const tenant = await storage.archiveTenantProfile(req.params.id);
      await storage.logTransactionEvent({
        merchantId,
        tenantProfileId: req.params.id,
        eventType: "Tenant_Archived",
        payload: {},
      } as any);
      res.json(tenant);
    } catch (error) {
      console.error("Error archiving tenant:", error);
      res.status(500).json({ message: "Failed to archive tenant" });
    }
  });

  // Bulk CSV import of tenant profiles
  app.post("/api/property/tenants/import", authenticateToken, csvUpload.single("file"), async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      if (!req.file) return res.status(400).json({ message: "No file uploaded" });

      const csv = req.file.buffer.toString("utf-8");
      const lines = csv.split(/\r?\n/).filter(l => l.trim());
      if (lines.length < 2) return res.status(400).json({ message: "CSV has no data rows" });

      // Parse header to find column indices (case-insensitive)
      const header = lines[0].split(",").map(h => h.trim().toLowerCase());
      const col = (name: string) => header.indexOf(name);
      const FIELDS = ["firstname","lastname","email","phone","propertyaddress","cotenantstext","preferredchannel"];
      const missing = FIELDS.slice(0,5).filter(f => col(f) === -1);
      if (missing.length) return res.status(400).json({ message: `CSV missing columns: ${missing.join(", ")}` });

      const imported: string[] = [];
      const failed: { row: number; reason: string }[] = [];

      for (let i = 1; i < lines.length; i++) {
        const cells = lines[i].split(",").map(c => c.trim().replace(/^"|"$/g, ""));
        const get = (name: string) => cells[col(name)] ?? "";
        try {
          const data = createTenantProfileSchema.parse({
            firstName: get("firstname"),
            lastName: get("lastname"),
            email: get("email") || undefined,
            phone: get("phone") || undefined,
            propertyAddress: get("propertyaddress"),
            coTenantsText: get("cotenantstext") || undefined,
            preferredChannel: get("preferredchannel") || "email",
          });
          const tenant = await storage.createTenantProfile({ ...data, merchantId } as any);
          await storage.logTransactionEvent({
            merchantId,
            tenantProfileId: tenant.id,
            eventType: "Tenant_Created",
            payload: { source: "csv_import", row: i },
          } as any);
          imported.push(tenant.id);
        } catch (err: any) {
          failed.push({ row: i + 1, reason: err?.errors?.[0]?.message ?? err?.message ?? "Invalid row" });
        }
      }

      res.json({ imported: imported.length, failed });
    } catch (error) {
      console.error("CSV import error:", error);
      res.status(500).json({ message: "Import failed" });
    }
  });

  // Get tenant activity timeline
  app.get("/api/property/tenants/:id/events", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const existing = await storage.getTenantProfile(req.params.id);
      if (!existing) return res.status(404).json({ message: "Tenant not found" });
      if (!checkMerchantOwnership(req, existing.merchantId)) return res.status(403).json({ message: "Access denied" });
      const limit = Math.min(parseInt(String(req.query.limit ?? "50")), 200);
      const events = await storage.getTransactionEventsByTenant(req.params.id, limit);
      res.json(events);
    } catch (error) {
      console.error("Error fetching tenant events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });

  // ─── Recurring Schedules ───────────────────────────────────────────────────

  // List schedules for a tenant
  app.get("/api/property/tenants/:tenantId/schedules", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const tenant = await storage.getTenantProfile(req.params.tenantId);
      if (!tenant) return res.status(404).json({ message: "Tenant not found" });
      if (!checkMerchantOwnership(req, tenant.merchantId)) return res.status(403).json({ message: "Access denied" });
      const schedules = await storage.getActiveSchedulesByTenant(req.params.tenantId);
      res.json(schedules);
    } catch (error) {
      console.error("Error listing schedules:", error);
      res.status(500).json({ message: "Failed to fetch schedules" });
    }
  });

  // Create schedule for a tenant
  app.post("/api/property/tenants/:tenantId/schedules", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const tenant = await storage.getTenantProfile(req.params.tenantId);
      if (!tenant) return res.status(404).json({ message: "Tenant not found" });
      if (!checkMerchantOwnership(req, tenant.merchantId)) return res.status(403).json({ message: "Access denied" });
      const data = createActiveScheduleSchema.parse({ ...req.body, tenantProfileId: req.params.tenantId });
      const schedule = await storage.createActiveSchedule({
        ...data,
        merchantId,
        nextRunDate: data.startDate,
      } as any);
      await storage.logTransactionEvent({
        merchantId,
        tenantProfileId: req.params.tenantId,
        scheduleId: schedule.id,
        eventType: "Schedule_Created",
        payload: { amountCents: schedule.amountCents, frequency: schedule.frequency },
      } as any);
      res.status(201).json(schedule);
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ message: "Validation error", errors: error.errors });
      console.error("Error creating schedule:", error);
      res.status(500).json({ message: "Failed to create schedule" });
    }
  });

  // Update schedule (amount, frequency, pause toggle, etc.)
  app.put("/api/property/schedules/:id", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const existing = await storage.getActiveSchedule(req.params.id);
      if (!existing) return res.status(404).json({ message: "Schedule not found" });
      if (!checkMerchantOwnership(req, existing.merchantId)) return res.status(403).json({ message: "Access denied" });
      const data = updateActiveScheduleSchema.parse(req.body);
      const schedule = await storage.updateActiveSchedule(req.params.id, data as any);
      if (data.pauseNextCycle !== undefined) {
        await storage.logTransactionEvent({
          merchantId,
          tenantProfileId: existing.tenantProfileId,
          scheduleId: req.params.id,
          eventType: data.pauseNextCycle ? "Schedule_Paused" : "Schedule_Resumed",
          payload: {},
        } as any);
      }
      res.json(schedule);
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ message: "Validation error", errors: error.errors });
      console.error("Error updating schedule:", error);
      res.status(500).json({ message: "Failed to update schedule" });
    }
  });

  // Terminate schedule
  app.delete("/api/property/schedules/:id", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const existing = await storage.getActiveSchedule(req.params.id);
      if (!existing) return res.status(404).json({ message: "Schedule not found" });
      if (!checkMerchantOwnership(req, existing.merchantId)) return res.status(403).json({ message: "Access denied" });
      const schedule = await storage.terminateActiveSchedule(req.params.id);
      await storage.logTransactionEvent({
        merchantId,
        tenantProfileId: existing.tenantProfileId,
        scheduleId: req.params.id,
        eventType: "Schedule_Terminated",
        payload: {},
      } as any);
      res.json(schedule);
    } catch (error) {
      console.error("Error terminating schedule:", error);
      res.status(500).json({ message: "Failed to terminate schedule" });
    }
  });

  // ─── Invoices / Rent Requests ──────────────────────────────────────────────

  // List invoices for merchant (optional ?tenantProfileId= ?status= filters)
  // Enriches each invoice with tenantName and propertyAddress for dashboard display.
  app.get("/api/property/invoices", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const tenantProfileId = typeof req.query.tenantProfileId === "string" ? req.query.tenantProfileId : undefined;
      const status = typeof req.query.status === "string" ? req.query.status : undefined;
      const invoices = await storage.getInvoiceRentRequestsByMerchant(merchantId, { status, tenantProfileId });
      // Enrich with tenant display fields (best-effort, no extra round-trips for missing tenants)
      const tenantCache = new Map<string, { tenantName: string; propertyAddress: string }>();
      const enriched = await Promise.all(invoices.map(async inv => {
        if (!tenantCache.has(inv.tenantProfileId)) {
          const t = await storage.getTenantProfile(inv.tenantProfileId).catch(() => null);
          tenantCache.set(inv.tenantProfileId, t
            ? { tenantName: `${t.firstName} ${t.lastName}`, propertyAddress: t.propertyAddress }
            : { tenantName: "—", propertyAddress: "—" });
        }
        return { ...inv, ...tenantCache.get(inv.tenantProfileId) };
      }));
      res.json(enriched);
    } catch (error) {
      console.error("Error listing invoices:", error);
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  // Create ad-hoc invoice (terminal send)
  app.post("/api/property/invoices", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const tenant = await storage.getTenantProfile(req.body.tenantProfileId);
      if (!tenant) return res.status(404).json({ message: "Tenant not found" });
      if (!checkMerchantOwnership(req, tenant.merchantId)) return res.status(403).json({ message: "Access denied" });
      const data = createAdHocInvoiceSchema.parse(req.body);
      const invoice = await storage.createInvoiceRentRequest({
        ...data,
        merchantId,
        token: generateInvoiceToken(),
        status: "pending_dispatch",
      } as any);
      await storage.logTransactionEvent({
        merchantId,
        tenantProfileId: data.tenantProfileId,
        invoiceId: invoice.id,
        eventType: "Invoice_Generated",
        payload: { amountCents: invoice.amountCents, channel: invoice.deliveryChannel },
      } as any);
      res.status(201).json(invoice);
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ message: "Validation error", errors: error.errors });
      console.error("Error creating invoice:", error);
      res.status(500).json({ message: "Failed to create invoice" });
    }
  });

  // Get single invoice
  app.get("/api/property/invoices/:id", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const invoice = await storage.getInvoiceRentRequest(req.params.id);
      if (!invoice) return res.status(404).json({ message: "Invoice not found" });
      if (!checkMerchantOwnership(req, invoice.merchantId)) return res.status(403).json({ message: "Access denied" });
      res.json(invoice);
    } catch (error) {
      console.error("Error fetching invoice:", error);
      res.status(500).json({ message: "Failed to fetch invoice" });
    }
  });

  // Void invoice
  app.post("/api/property/invoices/:id/void", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const invoice = await storage.getInvoiceRentRequest(req.params.id);
      if (!invoice) return res.status(404).json({ message: "Invoice not found" });
      if (!checkMerchantOwnership(req, invoice.merchantId)) return res.status(403).json({ message: "Access denied" });
      if (["paid", "paid_external"].includes(invoice.status)) {
        return res.status(400).json({ message: "Cannot void a paid invoice" });
      }
      const updated = await storage.updateInvoiceRentRequest(req.params.id, {
        status: "voided",
        voidedAt: new Date(),
      } as any);
      await storage.logTransactionEvent({
        merchantId,
        tenantProfileId: invoice.tenantProfileId,
        invoiceId: req.params.id,
        eventType: "Invoice_Voided",
        payload: {},
      } as any);
      res.json(updated);
    } catch (error) {
      console.error("Error voiding invoice:", error);
      res.status(500).json({ message: "Failed to void invoice" });
    }
  });

  // Mark invoice paid externally (bank transfer / cheque)
  app.post("/api/property/invoices/:id/mark-paid-external", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const invoice = await storage.getInvoiceRentRequest(req.params.id);
      if (!invoice) return res.status(404).json({ message: "Invoice not found" });
      if (!checkMerchantOwnership(req, invoice.merchantId)) return res.status(403).json({ message: "Access denied" });
      if (invoice.status === "paid" || invoice.status === "paid_external") {
        return res.status(400).json({ message: "Invoice is already marked as paid" });
      }
      const { externalPaymentReference } = markInvoicePaidExternalSchema.parse(req.body);
      const updated = await storage.updateInvoiceRentRequest(req.params.id, {
        status: "paid_external",
        paidAt: new Date(),
        externalPaymentReference: externalPaymentReference ?? null,
      } as any);
      await storage.logTransactionEvent({
        merchantId,
        tenantProfileId: invoice.tenantProfileId,
        invoiceId: req.params.id,
        eventType: "Payment_External",
        payload: { externalPaymentReference },
      } as any);
      res.json(updated);
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ message: "Validation error", errors: error.errors });
      console.error("Error marking invoice paid:", error);
      res.status(500).json({ message: "Failed to mark invoice as paid" });
    }
  });

  // ─── Merchant Sector (retail ↔ propertyManagement) ────────────────────────

  app.put("/api/merchants/:merchantId/sector", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = parseInt(req.params.merchantId);
      if (!checkMerchantOwnership(req, merchantId)) return res.status(403).json({ message: "Access denied" });
      const { sector } = z.object({ sector: z.enum(["retail", "propertyManagement"]) }).parse(req.body);
      const merchant = await storage.updateMerchant(merchantId, { sector } as any);
      res.json({ sector: (merchant as any)?.sector });
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ message: "Validation error", errors: error.errors });
      console.error("Error updating sector:", error);
      res.status(500).json({ message: "Failed to update sector" });
    }
  });

  // ─── Merchant Timezone ─────────────────────────────────────────────────────

  app.put("/api/property/settings/timezone", authenticateToken, async (req: AuthenticatedRequest, res) => {
    try {
      const merchantId = req.user?.merchantId;
      if (!merchantId) return res.status(401).json({ message: "Authentication required" });
      const { timezone } = updateMerchantTimezoneSchema.parse(req.body);
      // Validate it's a real IANA timezone
      try { Intl.DateTimeFormat(undefined, { timeZone: timezone }); } catch {
        return res.status(400).json({ message: "Invalid timezone identifier" });
      }
      const merchant = await storage.updateMerchant(merchantId, { timezone } as any);
      res.json({ timezone: merchant?.timezone });
    } catch (error) {
      if (error instanceof z.ZodError) return res.status(400).json({ message: "Validation error", errors: error.errors });
      console.error("Error updating timezone:", error);
      res.status(500).json({ message: "Failed to update timezone" });
    }
  });

  // ===========================================================================
  // INTERNAL CRON — Phase 3 automation engine
  // ===========================================================================
  // Must be called by an external scheduler (e.g. Render Cron Job, GitHub Actions)
  // with header  x-cron-secret: <CRON_SECRET env var>.
  // Run hourly. All three passes are idempotent.

  app.post("/api/internal/cron", async (req, res) => {
    const cronSecret = process.env.CRON_SECRET;
    if (!cronSecret) {
      // If no secret is configured, reject to prevent accidental exposure
      return res.status(503).json({ message: "Cron not configured" });
    }
    if (req.headers["x-cron-secret"] !== cronSecret) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const { runGeneratePass, runDispatchPass, runOverduePass } = await import("./property-cron");
    const now = new Date();
    const baseUrl = getBaseUrl(req);

    try {
      const [gen, disp, overdue] = await Promise.all([
        runGeneratePass(now),
        runDispatchPass(baseUrl),
        runOverduePass(now),
      ]);

      console.log(`[CRON] generate=${JSON.stringify(gen)} dispatch=${JSON.stringify(disp)} overdue=${JSON.stringify(overdue)}`);

      res.json({ ok: true, ranAt: now.toISOString(), generate: gen, dispatch: disp, overdue });
    } catch (error) {
      console.error("[CRON] Fatal error:", error);
      res.status(500).json({ message: "Cron run failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
