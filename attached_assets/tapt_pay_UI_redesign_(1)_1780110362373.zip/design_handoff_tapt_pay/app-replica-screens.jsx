// app-replica-screens.jsx — pixel replica of the Tapt Pay dashboard + tenant directory
// Two screens rendered inside iOS frames on a design canvas.

const { useState } = React;

// ── Palette sampled from the screenshots ─────────────────────────
const C = {
  navy:    '#040D6D',   // deep royal navy — top cards, stat card, bottom nav
  navy2:   '#0A1075',   // marginally darker for nav depth
  sky:     '#58ABFF',   // big numbers on navy, revenue card bg
  skyNum:  '#58ABFF',   // numerals
  btn:     '#3F9BFF',   // + button, filled/active nav
  ice:     '#ECEBEA',   // neumorphic ring card bg
  gray:    '#E7E6E5',   // placeholder / tile bg
  grayTrk: '#D7D6D4',   // ring track
  white:   '#FFFFFF',
  ink:     '#0A1280',   // navy text
  mute:    '#8C8C8C',   // gray subtext
  // status palette
  paid:     { dot: '#13C29A', bg: 'rgba(19,194,154,0.14)',  fg: '#0B7D63' },
  overdue:  { dot: '#FF3B4E', bg: 'rgba(255,59,78,0.12)',   fg: '#C71A2A' },
  dueSoon:  { dot: '#FFB02E', bg: 'rgba(255,176,46,0.18)',  fg: '#9A6A00' },
  upcoming: { dot: '#3F9BFF', bg: 'rgba(63,155,255,0.16)',  fg: '#1A5FCC' },
};

// ── Icons ─────────────────────────────────────────────────────────
function G({ n, c = 'currentColor', s = 18, sw = 1.8, fill = false }) {
  const p = { width: s, height: s, viewBox: '0 0 24 24', fill: fill ? c : 'none',
    stroke: c, strokeWidth: sw, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (n) {
    case 'tenants': return <svg width={s} height={s} viewBox="0 0 24 24" fill={c}><circle cx="8.5" cy="8" r="3"/><circle cx="16" cy="8.5" r="2.4"/><path d="M2.6 19c0-3.2 2.6-5.6 5.9-5.6s5.9 2.4 5.9 5.6z"/><path d="M15.4 13.6c2.6.2 4.9 2.3 4.9 5.1"/></svg>;
    case 'warn':    return <svg {...p}><path d="M12 3.6 21 19H3z"/><path d="M12 10v4.1"/><circle cx="12" cy="16.6" r=".95" fill={c} stroke="none"/></svg>;
    case 'page':    return <svg {...p}><path d="M6 3h8l4 4v14H6z"/><path d="M14 3v4h4"/><path d="M9 12h6M9 15.5h6"/></svg>;
    case 'pause':   return <svg width={s} height={s} viewBox="0 0 24 24" fill={c}><rect x="6.5" y="4.5" width="3.6" height="15" rx="1.3"/><rect x="13.9" y="4.5" width="3.6" height="15" rx="1.3"/></svg>;
    case 'plus':    return <svg {...p}><path d="M12 5v14M5 12h14"/></svg>;
    case 'search':  return <svg {...p}><circle cx="11" cy="11" r="6.5"/><path d="m20 20-3.5-3.5"/></svg>;
    case 'chev':    return <svg {...p}><path d="m9 6 6 6-6 6"/></svg>;
    case 'pencil':  return <svg {...p}><path d="M14.5 4.5l5 5M3.5 20.5l1-4.2L16 4.8a2 2 0 0 1 2.8 0l.4.4a2 2 0 0 1 0 2.8L7.7 19.5z"/></svg>;
    case 'home':    return <svg width={s} height={s} viewBox="0 0 24 24" fill={c}><path d="M3 11 12 3.5 21 11v9.2a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/></svg>;
    case 'grid':    return <svg width={s} height={s} viewBox="0 0 24 24" fill={c}><rect x="3.4" y="3.4" width="7.2" height="7.2" rx="2"/><rect x="13.4" y="3.4" width="7.2" height="7.2" rx="2"/><rect x="3.4" y="13.4" width="7.2" height="7.2" rx="2"/><rect x="13.4" y="13.4" width="7.2" height="7.2" rx="2"/></svg>;
    case 'terminal':return <svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke={c} strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round"><path d="M5 7l5 5-5 5"/><path d="M13 17h6"/></svg>;
    case 'chart':   return <svg width={s} height={s} viewBox="0 0 24 24" fill={c}><rect x="3.5" y="12" width="4" height="8" rx="1.2"/><rect x="10" y="7" width="4" height="13" rx="1.2"/><rect x="16.5" y="9.5" width="4" height="10.5" rx="1.2"/></svg>;
    case 'gear':    return <svg width={s} height={s} viewBox="0 0 24 24" fill={c}><path d="M12 8.6a3.4 3.4 0 1 0 0 6.8 3.4 3.4 0 0 0 0-6.8zm9 3.4a7.6 7.6 0 0 0-.1-1.2l2-1.6-2-3.4-2.4 1a7.3 7.3 0 0 0-2-1.2L16 2h-4l-.5 2.6a7.3 7.3 0 0 0-2 1.2l-2.4-1-2 3.4 2 1.6a7.6 7.6 0 0 0 0 2.4l-2 1.6 2 3.4 2.4-1a7.3 7.3 0 0 0 2 1.2L12 22h4l.5-2.6a7.3 7.3 0 0 0 2-1.2l2.4 1 2-3.4-2-1.6c.07-.4.1-.8.1-1.2z"/></svg>;
    case 'chevd':   return <svg {...p}><path d="m6 9 6 6 6-6"/></svg>;
    case 'back':    return <svg {...p}><path d="m15 6-6 6 6 6"/></svg>;
    case 'check':   return <svg {...p}><path d="m5 12.5 4.5 4.5L19 7"/></svg>;
    case 'x':       return <svg {...p}><path d="M6 6l12 12M18 6 6 18"/></svg>;
    case 'send':    return <svg {...p}><path d="M21 4 3 11l6 2.5L12 20l3-7z"/><path d="m9 13.5 6-6.5"/></svg>;
    case 'bell':    return <svg {...p}><path d="M18 8a6 6 0 1 0-12 0c0 6-2.5 7-2.5 7h17S18 14 18 8z"/><path d="M10.5 20.5a2 2 0 0 0 3 0"/></svg>;
    case 'card':    return <svg {...p}><rect x="3" y="5.5" width="18" height="13" rx="2.5"/><path d="M3 9.5h18"/></svg>;
    case 'clock':   return <svg {...p}><circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/></svg>;
    case 'cash':    return <svg {...p}><rect x="3" y="6" width="18" height="12" rx="2.5"/><circle cx="12" cy="12" r="2.6"/></svg>;
    default: return null;
  }
}

// ── Bottom nav (shared) ───────────────────────────────────────────
function BottomNav({ active = 'home' }) {
  const items = [
    { id: 'home',     i: 'home'     },
    { id: 'tenants',  i: 'grid'     },
    { id: 'terminal', i: 'terminal' },
    { id: 'overview', i: 'chart'    },
    { id: 'settings', i: 'gear'     },
  ];
  return (
    <div style={{
      position: 'absolute', left: 22, right: 22, bottom: 30,
      height: 62, background: C.navy, borderRadius: 999,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 26px', zIndex: 40,
      boxShadow: '0 16px 30px rgba(4,13,109,0.34)',
    }}>
      {items.map((it) => {
        const on = it.id === active;
        return (
          <div key={it.id} style={{
            width: 42, height: 42, borderRadius: 999,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            background: on ? 'rgba(63,155,255,0.18)' : 'transparent',
          }}>
            <G n={it.i} c={on ? C.btn : C.sky} s={on ? 23 : 22} fill />
          </div>
        );
      })}
    </div>
  );
}

const fmt = (n) => '$' + n.toLocaleString();

// sleek refractive frosted-glass shell
const glassShell = {
  background: 'linear-gradient(140deg, rgba(255,255,255,0.80) 0%, rgba(234,238,244,0.52) 50%, rgba(220,227,240,0.46) 100%)',
  backdropFilter: 'blur(16px) saturate(130%)',
  WebkitBackdropFilter: 'blur(16px) saturate(130%)',
  border: '1px solid rgba(255,255,255,0.6)',
  boxShadow: '0 12px 32px rgba(4,13,109,0.10)',
};
// card with a moving light-refraction sheen + chromatic rim
function GlassCard({ radius = 18, style = {}, children, ...rest }) {
  return (
    <div {...rest} style={{ position: 'relative', overflow: 'hidden', borderRadius: radius, ...glassShell }}>
      <div className="glass-rim" />
      <div className="glass-sheen" />
      <div style={{ position: 'relative', zIndex: 2, height: '100%', boxSizing: 'border-box', ...style }}>{children}</div>
    </div>
  );
}

// ── Status box (the "clear status" gap) ──────────────────────────
function StatusBox({ st, big = false }) {
  const map = { paid: ['paid', C.paid], overdue: ['overdue', C.overdue], dueSoon: ['due soon', C.dueSoon], upcoming: ['upcoming', C.upcoming] };
  const [label, s] = map[st];
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: big ? '6px 11px' : '4px 9px', borderRadius: 8,
      background: s.bg, color: s.fg,
      fontWeight: 600, fontSize: big ? 11 : 9.5, letterSpacing: '0.06em', textTransform: 'uppercase',
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: s.dot }} />
      {label}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════
// SCREEN 1 — DASHBOARD
// ══════════════════════════════════════════════════════════════════
const STAT = [
  { i: 'tenants', label: 'tenants',     v: '250' },
  { i: 'warn',    label: 'outstanding', v: '15'  },
  { i: 'page',    label: 'queued',      v: '85'  },
  { i: 'pause',   label: 'paused',      v: '8'   },
];

const TXNS = [
  { i: 'JS', name: 'john smith',   addr: '5 honeysuckle lane', amt: 650,  st: 'upcoming' },
  { i: 'MC', name: 'marcus chen',  addr: '88 victoria st',     amt: 2100, st: 'overdue'  },
  { i: 'SL', name: 'sarah linton', addr: '12 ponsonby road',   amt: 1550, st: 'paid'     },
];

function Ring75() {
  const cx = 65, cy = 65;
  const r = 48;                 // progress ring radius — sits OUTSIDE the inner disk
  const circ = 2 * Math.PI * r;
  const pct = 0.75;
  const diskR = 37;             // inner light-grey disk — a touch bigger
  const endAng = (135 + 360 * pct) * Math.PI / 180;  // knob sits exactly at the bar's end, tracks pct
  return (
    <svg width="130" height="130" viewBox="0 0 130 130" style={{ display: 'block' }}>
      <defs>
        {/* depth shadow for the inner disk — soft, extends further so it blends */}
        <filter id="diskDepth" x="-90%" y="-90%" width="280%" height="280%">
          <feDropShadow dx="0" dy="2.5" stdDeviation="7" floodColor="rgba(4,13,109,0.22)" />
        </filter>
        {/* soft glow on the blue arc — wider + lighter so it blends into the disk shadow */}
        <filter id="arcGlow" x="-80%" y="-80%" width="260%" height="260%">
          <feDropShadow dx="0" dy="0.5" stdDeviation="4" floodColor={C.navy} floodOpacity="0.32" />
        </filter>
      </defs>

      {/* inner light-grey disk with drop shadow — bar sits outside it */}
      <circle cx={cx} cy={cy} r={diskR} fill="#EAEAEA" filter="url(#diskDepth)" />

      {/* white track — white at 80% opacity, thinner */}
      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#FFFFFF" strokeOpacity="0.8" strokeWidth="1.5" />

      {/* blue progress bar — thinner, with a soft glow */}
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={C.navy} strokeWidth="2.5" strokeLinecap="round"
        strokeDasharray={`${circ * pct} ${circ}`} transform={`rotate(135 ${cx} ${cy})`}
        filter="url(#arcGlow)" />

      {/* knob — sits exactly at the end of the blue bar and tracks it as pct changes */}
      <circle cx={cx + r * Math.cos(endAng)} cy={cy + r * Math.sin(endAng)} r="5.5" fill={C.navy} filter="url(#arcGlow)" />

      <text x={cx} y={cy + 5} textAnchor="middle" fontFamily="Outfit, sans-serif" fontWeight="400" fontSize="19" fill={C.navy} letterSpacing="-0.02em">75%</text>
    </svg>
  );
}

function DashboardScreen() {
  return (
    <IOSDevice width={402} height={874}>
      <div style={{ background: C.white, minHeight: '100%', position: 'relative', paddingTop: 58, paddingBottom: 130 }}>
        {/* 1 · active transactions hero */}
        <div style={{ padding: '0 18px' }}>
          <div style={{ background: C.navy, borderRadius: 24, padding: '24px 26px 26px' }}>
            <div style={{ fontFamily: '"Outfit",sans-serif', fontWeight: 900, fontSize: 62, color: C.sky, letterSpacing: '-0.04em', lineHeight: 0.92, fontVariantNumeric: 'tabular-nums' }}>155</div>
            <div style={{ fontWeight: 500, fontSize: 12, color: C.sky, letterSpacing: '0.16em', textTransform: 'uppercase', marginTop: 6 }}>active transaction</div>
            {/* progress bar */}
            <div style={{ marginTop: 18, height: 24, borderRadius: 999, border: `1.5px solid ${C.sky}`, padding: 3 }}>
              <div style={{ width: '82%', height: '100%', borderRadius: 999, background: C.sky }} />
            </div>
          </div>
        </div>

        {/* 2 · revenue + ring */}
        <div style={{ display: 'grid', gridTemplateColumns: '1.32fr 1fr', gap: 14, padding: '16px 18px 0' }}>
          <div style={{ background: C.sky, borderRadius: 22, padding: '24px 22px', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
            <div style={{ fontFamily: '"Outfit",sans-serif', fontWeight: 900, fontSize: 36, color: C.navy, letterSpacing: '-0.04em', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>$12,500</div>
            <div style={{ fontWeight: 500, fontSize: 11, color: C.navy, letterSpacing: '0.08em', textTransform: 'uppercase', marginTop: 12, lineHeight: 1.3 }}>monthly rent<br/>revenue</div>
          </div>
          <div style={{ background: '#F2F0F0', borderRadius: 22, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Ring75 />
          </div>
        </div>

        {/* 3 · stat strip */}
        <div style={{ padding: '16px 18px 0' }}>
          <div style={{ background: C.navy, borderRadius: 24, padding: '18px 16px' }}>
            <div style={{ border: '2px solid rgba(88,171,255,0.55)', borderRadius: 20, padding: 10, display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 13 }}>
              {STAT.map((d) => (
                <div key={d.label} style={{ borderRadius: 18, padding: '12px 11px', textAlign: 'left', background: C.sky, minHeight: 92, display: 'flex', flexDirection: 'column', justifyContent: 'flex-start', boxSizing: 'border-box' }}>
                  <div style={{ display: 'flex', justifyContent: 'flex-start', marginBottom: 8 }}>
                    <G n={d.i} c={C.navy} s={17} />
                  </div>
                  <div style={{ fontWeight: 700, fontSize: 7.5, color: C.navy, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 6, whiteSpace: 'nowrap' }}>{d.label}</div>
                  <div style={{ fontFamily: '"Outfit",sans-serif', fontWeight: 800, fontSize: 28, color: C.white, letterSpacing: '-0.03em', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{d.v}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 4 · rent transactions */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '22px 20px 12px' }}>
          <div style={{ fontWeight: 600, fontSize: 12, color: C.navy, letterSpacing: '0.12em', textTransform: 'uppercase' }}>rent transactions</div>
          <G n="chev" c={C.navy} s={15} sw={2.4} />
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: '0 18px' }}>
          {TXNS.map((t) => (
            <GlassCard key={t.i} style={{ padding: '14px 16px', display: 'flex', alignItems: 'center', gap: 13 }}>
              <div style={{ width: 40, height: 40, borderRadius: 999, background: C.navy, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontFamily: '"Outfit",sans-serif', fontWeight: 800, fontSize: 12, color: C.sky, letterSpacing: '0.03em', textTransform: 'uppercase' }}>{t.i}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 500, fontSize: 13.5, color: C.navy, textTransform: 'capitalize' }}>{t.name}</div>
                <div style={{ fontWeight: 400, fontSize: 11, color: C.mute, marginTop: 2, textTransform: 'capitalize' }}>{t.addr}</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 5, flexShrink: 0 }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: C.navy, fontVariantNumeric: 'tabular-nums' }}>{fmt(t.amt)}</div>
                <StatusBox st={t.st} />
              </div>
            </GlassCard>
          ))}
        </div>

        <BottomNav active="home" />
      </div>
    </IOSDevice>
  );
}

// ══════════════════════════════════════════════════════════════════
// SCREEN 2 — TENANT DIRECTORY
// ══════════════════════════════════════════════════════════════════
const TENANTS = [
  { name: 'john smith',    addr: '5 honeysuckle lane', n: 4, amt: 650,  date: '31/05/26', st: 'upcoming' },
  { name: 'sarah linton',  addr: '12 ponsonby road',   n: 2, amt: 1550, date: '03/06/26', st: 'paid'     },
  { name: 'marcus chen',   addr: '88 victoria street', n: 6, amt: 2100, date: '28/05/26', st: 'overdue'  },
  { name: 'amelia hart',   addr: '4/22 jervois road',  n: 3, amt: 1800, date: '05/06/26', st: 'dueSoon'  },
];

function TenantRow({ t }) {
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1.7fr 1fr', gap: 12 }}>
      {/* info card — with edit button + status box (the gaps) */}
      <GlassCard style={{ padding: '16px 16px 14px', position: 'relative', display: 'flex', flexDirection: 'column' }}>
        {/* edit button */}
        <button style={{ position: 'absolute', top: 12, right: 12, width: 28, height: 28, borderRadius: 999, background: C.white, border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', boxShadow: '0 1px 3px rgba(4,13,109,0.12)' }}>
          <G n="pencil" c={C.navy} s={14} sw={1.9} />
        </button>
        <div style={{ fontWeight: 500, fontSize: 14, color: C.navy, textTransform: 'uppercase', letterSpacing: '0.02em', paddingRight: 30, lineHeight: 1.25 }}>{t.name}</div>
        <div style={{ fontWeight: 400, fontSize: 12.5, color: C.navy, textTransform: 'uppercase', letterSpacing: '0.02em', marginTop: 5, lineHeight: 1.35 }}>{t.addr}</div>
        <div style={{ fontWeight: 400, fontSize: 12.5, color: C.navy, textTransform: 'uppercase', letterSpacing: '0.02em', marginTop: 2 }}>{t.n} tenants</div>
        <div style={{ marginTop: 12 }}>
          <StatusBox st={t.st} big />
        </div>
      </GlassCard>
      {/* payment card */}
      <GlassCard style={{ padding: '16px 12px', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', textAlign: 'center' }}>
        <div style={{ fontFamily: '"Outfit",sans-serif', fontWeight: 900, fontSize: 27, color: C.navy, letterSpacing: '-0.03em', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>{fmt(t.amt)}</div>
        <div style={{ fontWeight: 400, fontSize: 11, color: C.mute, marginTop: 8 }}>next payment</div>
        <div style={{ fontWeight: 500, fontSize: 11, color: C.mute, marginTop: 1, fontVariantNumeric: 'tabular-nums' }}>{t.date}</div>
      </GlassCard>
    </div>
  );
}

function TenantDirectoryScreen() {
  const [q, setQ] = useState('');
  const term = q.trim().toLowerCase();
  const list = TENANTS.filter(t => !term || t.name.includes(term) || t.addr.includes(term));
  return (
    <IOSDevice width={402} height={874}>
      <div style={{ background: C.white, minHeight: '100%', position: 'relative', paddingTop: 58, paddingBottom: 130 }}>
        {/* hero */}
        <div style={{ padding: '0 18px' }}>
          <div style={{ background: C.navy, borderRadius: 24, padding: '26px 26px 30px', position: 'relative' }}>
            <div style={{ fontFamily: '"Outfit",sans-serif', fontWeight: 900, fontSize: 64, color: C.sky, letterSpacing: '-0.04em', lineHeight: 0.92, fontVariantNumeric: 'tabular-nums' }}>250</div>
            <div style={{ fontWeight: 500, fontSize: 12, color: C.sky, letterSpacing: '0.16em', textTransform: 'uppercase', marginTop: 6 }}>active tenants</div>
            {/* + button overlapping bottom-right edge */}
            <button style={{ position: 'absolute', right: 24, bottom: -20, width: 46, height: 46, borderRadius: 999, background: C.btn, border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', boxShadow: '0 6px 16px rgba(63,155,255,0.45)' }}>
              <G n="plus" c={C.navy} s={22} sw={2.6} />
            </button>
          </div>
        </div>

        {/* search */}
        <div style={{ padding: '38px 18px 0', display: 'flex', gap: 10 }}>
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 10, background: C.gray, borderRadius: 14, padding: '0 14px', height: 46 }}>
            <G n="search" c={C.navy} s={18} sw={2} />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search tenants or address"
              style={{ flex: 1, minWidth: 0, border: 'none', outline: 'none', background: 'transparent', fontFamily: 'Outfit, sans-serif', fontWeight: 500, fontSize: 14, color: C.navy }}
            />
            {q && (
              <button onClick={() => setQ('')} style={{ border: 'none', background: 'transparent', cursor: 'pointer', display: 'flex', padding: 0 }}>
                <G n="x" c={C.mute} s={16} sw={2.2} />
              </button>
            )}
          </div>
          <button style={{ width: 46, height: 46, borderRadius: 14, background: C.navy, border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', flexShrink: 0 }}>
            <G n="grid" c={C.sky} s={20} fill />
          </button>
        </div>

        {/* tenant rows */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14, padding: '16px 18px 0' }}>
          {list.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 0', color: C.mute, fontWeight: 500, fontSize: 13 }}>No tenants match “{q}”.</div>
          ) : (
            list.map((t) => <TenantRow key={t.name} t={t} />)
          )}
        </div>

        <BottomNav active="tenants" />
      </div>
    </IOSDevice>
  );
}

// ══════════════════════════════════════════════════════════════════
// SCREEN 3 — TENANT PROFILE / EDIT
// ══════════════════════════════════════════════════════════════════
// editable field block inside the navy panel
function Field({ label, value, drop = false, wide = false }) {
  return (
    <div style={{
      background: 'rgba(255,255,255,0.07)', borderRadius: 12, padding: '10px 12px',
      gridColumn: wide ? '1 / -1' : 'auto', minWidth: 0,
    }}>
      <div style={{ fontWeight: 600, fontSize: 8.5, color: C.sky, letterSpacing: '0.12em', textTransform: 'uppercase' }}>{label}</div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, marginTop: 5 }}>
        <div style={{ fontWeight: 500, fontSize: 14, color: C.white, letterSpacing: '-0.01em', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{value}</div>
        {drop && <G n="chevd" c={C.sky} s={15} sw={2} />}
      </div>
    </div>
  );
}

// timeline rail (vertical line + node)
function Rail({ color, first, last }) {
  return (
    <div style={{ position: 'relative', width: 30, flexShrink: 0, display: 'flex', justifyContent: 'center' }}>
      {/* connecting line */}
      <div style={{ position: 'absolute', top: first ? 14 : 0, bottom: last ? 'calc(100% - 14px)' : 0, width: 2, background: 'rgba(4,13,109,0.14)' }} />
      {/* node */}
      <div style={{ position: 'absolute', top: 8, width: 13, height: 13, borderRadius: 999, background: C.white, border: `3px solid ${color}`, boxShadow: '0 0 0 3px rgba(255,255,255,0.9)' }} />
    </div>
  );
}

const TLINE = [
  { kind: 'paid',     title: 'Rent paid',           meta: '$650 received',        date: '03 May · 9:02 AM', card: true },
  { kind: 'sent',     title: 'Rent link sent',      meta: 'via email',            date: '01 May · 9:00 AM' },
  { kind: 'reminder', title: 'Reminder notice sent',meta: 'auto reminder · email',date: '28 Apr · 10:00 AM' },
  { kind: 'failed',   title: 'Payment failed',      meta: 'card declined',        date: '26 Apr · 9:15 AM' },
  { kind: 'sent',     title: 'Rent link sent',      meta: 'via email',            date: '18 Apr · 9:00 AM' },
];
const TKIND = {
  paid:     { color: C.paid.dot,     icon: 'cash',  fg: C.paid.fg },
  sent:     { color: C.upcoming.dot, icon: 'send',  fg: C.upcoming.fg },
  reminder: { color: C.dueSoon.dot,  icon: 'bell',  fg: C.dueSoon.fg },
  failed:   { color: C.overdue.dot,  icon: 'x',     fg: C.overdue.fg },
};

function TenantProfileScreen() {
  const [open, setOpen] = useState(false);
  return (
    <IOSDevice width={402} height={874}>
      <div style={{ background: C.white, minHeight: '100%', position: 'relative', paddingTop: 56, paddingBottom: 130 }}>
        {/* top bar */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '6px 18px 14px' }}>
          <button style={{ width: 34, height: 34, borderRadius: 999, background: C.gray, border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <G n="back" c={C.navy} s={18} sw={2.2} />
          </button>
          <div style={{ fontWeight: 600, fontSize: 11, color: C.navy, letterSpacing: '0.16em', textTransform: 'uppercase' }}>tenant profile</div>
          <button style={{ width: 34, height: 34, borderRadius: 999, background: C.gray, border: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
            <G n="pencil" c={C.navy} s={15} sw={1.9} />
          </button>
        </div>

        {/* navy editable panel */}
        <div style={{ padding: '0 18px' }}>
          <div style={{ background: C.navy, borderRadius: 24, padding: '20px 20px 22px' }}>
            {/* head */}
            <div style={{ display: 'flex', alignItems: 'center', gap: 13 }}>
              <div style={{ width: 50, height: 50, borderRadius: 999, background: C.sky, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, fontWeight: 800, fontSize: 16, color: C.navy, letterSpacing: '0.03em' }}>JS</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 600, fontSize: 8.5, color: C.sky, letterSpacing: '0.12em', textTransform: 'uppercase' }}>head tenant</div>
                <div style={{ fontWeight: 600, fontSize: 21, color: C.white, letterSpacing: '-0.02em', marginTop: 2 }}>John Smith</div>
              </div>
              <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '5px 10px', borderRadius: 8, background: 'rgba(63,155,255,0.22)', color: C.sky, fontWeight: 700, fontSize: 9.5, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
                <span style={{ width: 6, height: 6, borderRadius: 999, background: C.btn }} />upcoming
              </div>
            </div>

            {/* subtenants dropdown (interactive) */}
            <div style={{ marginTop: 16 }}>
              <button onClick={() => setOpen(!open)} style={{ width: '100%', textAlign: 'left', background: 'rgba(255,255,255,0.07)', borderRadius: 12, padding: '10px 12px', border: 'none', cursor: 'pointer' }}>
                <div style={{ fontWeight: 600, fontSize: 8.5, color: C.sky, letterSpacing: '0.12em', textTransform: 'uppercase' }}>subtenants</div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, marginTop: 5 }}>
                  <div style={{ fontWeight: 500, fontSize: 14, color: C.white }}>3 subtenants</div>
                  <div style={{ transform: open ? 'rotate(180deg)' : 'none', transition: 'transform .2s', display: 'flex' }}>
                    <G n="chevd" c={C.sky} s={15} sw={2} />
                  </div>
                </div>
              </button>
              {open && (
                <div style={{ background: 'rgba(255,255,255,0.04)', borderRadius: 12, marginTop: 6, overflow: 'hidden' }}>
                  {['Mike Reyes', 'Anna Cole', 'Tom Webb'].map((n, i) => (
                    <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 12px', borderTop: i ? '1px solid rgba(255,255,255,0.06)' : 'none' }}>
                      <div style={{ width: 26, height: 26, borderRadius: 999, background: 'rgba(91,174,255,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: 9, color: C.sky }}>{n.split(' ').map(w => w[0]).join('')}</div>
                      <div style={{ fontWeight: 400, fontSize: 13, color: 'rgba(255,255,255,0.9)' }}>{n}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* fields grid */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginTop: 8 }}>
              <Field label="address" value="5 Honeysuckle Lane" wide />
              <Field label="rent amount" value="$650" />
              <Field label="frequency" value="Fortnightly" drop />
              <Field label="payment link via" value="Email" drop wide />
            </div>
          </div>
        </div>

        {/* timeline */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '24px 20px 4px' }}>
          <div style={{ fontWeight: 600, fontSize: 12, color: C.navy, letterSpacing: '0.12em', textTransform: 'uppercase' }}>activity timeline</div>
        </div>
        <div style={{ padding: '8px 18px 0' }}>
          {TLINE.map((t, i) => {
            const k = TKIND[t.kind];
            return (
              <div key={i} style={{ display: 'flex', gap: 10, minHeight: t.card ? 0 : 64 }}>
                <Rail color={k.color} first={i === 0} last={i === TLINE.length - 1} />
                <div style={{ flex: 1, paddingBottom: 14, paddingTop: 2 }}>
                  {t.card ? (
                    <div style={{ background: C.sky, borderRadius: 16, padding: '14px 15px', position: 'relative' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 16, color: C.navy, letterSpacing: '-0.01em' }}>{t.title}</div>
                          <div style={{ fontWeight: 500, fontSize: 12, color: 'rgba(4,13,109,0.7)', marginTop: 3 }}>{t.meta}</div>
                        </div>
                        <div style={{ fontWeight: 600, fontSize: 11, color: 'rgba(4,13,109,0.7)', fontVariantNumeric: 'tabular-nums' }}>{t.date}</div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 12 }}>
                        <div style={{ fontFamily: '"Outfit",sans-serif', fontWeight: 800, fontSize: 24, color: C.navy, letterSpacing: '-0.03em' }}>$650</div>
                        <div style={{ width: 30, height: 30, borderRadius: 999, background: C.navy, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                          <G n="check" c={C.sky} s={16} sw={2.4} />
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
                          <G n={k.icon} c={k.fg} s={14} sw={1.9} />
                          <div style={{ fontWeight: 600, fontSize: 14, color: C.navy }}>{t.title}</div>
                        </div>
                        <div style={{ fontWeight: 500, fontSize: 11, color: C.mute, fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{t.date}</div>
                      </div>
                      <div style={{ fontWeight: 400, fontSize: 11.5, color: C.mute, marginTop: 3 }}>{t.meta}</div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <BottomNav active="tenants" />
      </div>
    </IOSDevice>
  );
}

// ══════════════════════════════════════════════════════════════════
function AppReplicaCanvas() {
  const W = 462, H = 940;
  return (
    <DesignCanvas>
      <DCSection id="screens" title="Tapt Pay · dashboard + tenant directory">
        <DCArtboard id="dashboard" label="dashboard" width={W} height={H}>
          <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <DashboardScreen />
          </div>
        </DCArtboard>
        <DCArtboard id="tenants" label="tenant directory" width={W} height={H}>
          <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <TenantDirectoryScreen />
          </div>
        </DCArtboard>
        <DCArtboard id="profile" label="tenant profile / edit" width={W} height={H}>
          <div style={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <TenantProfileScreen />
          </div>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

Object.assign(window, { AppReplicaCanvas, TenantProfileScreen, TenantDirectoryScreen });