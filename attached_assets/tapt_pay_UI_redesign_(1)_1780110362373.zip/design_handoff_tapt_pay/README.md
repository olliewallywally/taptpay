# Handoff: Tapt Pay — Property Management (Mobile)

## Overview
Three mobile screens for the Tapt Pay property-management vertical:
1. **Dashboard** — active-transaction hero, monthly revenue + collection-rate gauge, a 4-up stat strip, and a recent rent-transactions list.
2. **Tenant Directory** — searchable list of all tenants (the "all profiles" screen, shown before drilling into one), each as an info card + payment card pair.
3. **Tenant Profile / Edit** — a single tenant's editable details (head tenant, subtenants, address, rent, frequency, payment-link delivery) plus a full rent activity timeline.

## About the Design Files
The files in this bundle are **design references created in HTML/React (via in-browser Babel)** — prototypes that show the intended look and behaviour. They are **not** production code to copy directly. The task is to **recreate these designs in the target codebase's environment** (React Native, Flutter, SwiftUI, native iOS/Android, or web) using its established components, navigation, and styling patterns. If no environment exists yet, pick the framework most appropriate for a mobile fintech app and implement there.

The prototypes render inside a mock iOS device frame (`ios-frame.jsx`) and are laid out on a pan/zoom design canvas (`design-canvas.jsx`). **Both are presentation scaffolding only — ignore them when implementing.** The real design lives in `app-replica-screens.jsx`.

## Fidelity
**High-fidelity.** Final colours, typography, spacing, and interactions are all specified below and in the source. Recreate pixel-faithfully using the codebase's own UI primitives. Designs are authored at a 402×874 logical viewport (iPhone-class).

---

## Design Tokens

### Colours
| Token | Hex | Use |
|---|---|---|
| navy | `#040D6D` | Primary brand navy — hero cards, stat strip, bottom nav, primary text |
| sky (light blue) | `#58ABFF` | Accent — hero numerals, revenue card bg, stat boxes, icons-on-navy |
| btn | `#3F9BFF` | Mid-blue — `+` button, active nav pill |
| white | `#FFFFFF` | — |
| gray | `#E7E6E5` | Legacy flat card bg (now replaced by glass; still used for small buttons/search field) |
| ring disk | `#EAEAEA` | Inner disk of the collection gauge |
| ring box bg | `#F2F0F0` | Gauge card background (flat, no shadow) |
| mute | `#8C8C8C` | Secondary/grey text ("next payment", dates, descriptions) |

### Status palette (dot / background / foreground)
| Status | Dot | Background | Foreground |
|---|---|---|---|
| paid | `#13C29A` | `rgba(19,194,154,0.14)` | `#0B7D63` |
| overdue | `#FF3B4E` | `rgba(255,59,78,0.12)` | `#C71A2A` |
| dueSoon | `#FFB02E` | `rgba(255,176,46,0.18)` | `#9A6A00` |
| upcoming | `#3F9BFF` | `rgba(63,155,255,0.16)` | `#1A5FCC` |

### Typography
- **Font family:** `Outfit` (bundled in `fonts/`, weights 300/400/500/600/700/900). Single typeface across the whole app.
- **Hero numerals** (155 active transactions, 250 active tenants): weight **900**, size 62–64px, letter-spacing −0.04em, line-height 0.92, tabular-nums.
- **Dollar figures** ($12,500, $650, etc.): weight 800–900, tabular-nums. Money is always the heaviest element on its card.
- **All other numbers** (75%, stat numbers): lighter — stat numbers are weight 800 **white** on the sky boxes.
- **Labels/eyebrows:** weight 500–700, 7.5–12px, uppercase, letter-spacing 0.06–0.16em.
- **Body/names:** weight 400–600, 11–14px.

### Radii / spacing
- Hero & section cards: radius 22–24px. Inner stat boxes: radius 18px. List/glass cards: radius 18px. Pills/dots: 999px.
- Screen horizontal padding: 18px. Bottom nav clearance: ~130px bottom padding.

### Shadows
- Cards: glass shell `0 12px 32px rgba(4,13,109,0.10)` + inner white rim (see Glass below).
- Bottom nav: `0 16px 30px rgba(10,18,128? → 4,13,109,0.34)` (navy tint).

---

## Screens / Views

### 1. Dashboard (`DashboardScreen`)
Top → bottom, all on white bg, 18px side padding:

1. **Active-transaction hero** — navy card (radius 24, padding 24/26). Contains `155` (sky, 900, 62px), label "ACTIVE TRANSACTION" (sky, 500, 12px, uppercase, 0.16em). Below: a **progress bar** — pill, height 24, 1.5px sky border, 3px inner padding, fill is sky at 82% width (rounded).
2. **Revenue + gauge row** — grid `1.32fr / 1fr`, gap 14:
   - **Revenue card** — sky bg, radius 22. `$12,500` (navy, 900, 36px) + "MONTHLY RENT / REVENUE" (navy, 500, 11px, uppercase).
   - **Gauge card** — `#F2F0F0` bg, radius 22, **no shadow**, centred SVG (see "Collection gauge" below).
3. **Stat strip** — navy card (radius 24). Inside: an outer frame with a **2px `rgba(88,171,255,0.55)` border**, radius 20, padding 10, containing a 4-col grid (gap 13) of **sky boxes** (radius 18, minHeight 92, identical size). Each box, **left-aligned**: navy icon (17px) → navy label (700, 7.5px, uppercase, nowrap) → white number (800, 28px). Data: TENANTS 250, OUTSTANDING 15, QUEUED 85, PAUSED 8.
4. **"RENT TRANSACTIONS ›"** section header (navy, 600, 12px, uppercase) + chevron.
5. **Transaction list** — glass cards (see Glass), 12px gap. Each row: navy circular avatar with initials (sky text) · name + address · right-aligned amount + StatusBox. Data: John Smith $650 upcoming; Marcus Chen $2,100 overdue; Sarah Linton $1,550 paid.
6. **Bottom nav** (see below), `home` active.

#### Collection gauge (SVG, 130×130, centred via `display:block`)
- Inner **disk**: filled circle `#EAEAEA`, r=37, with a soft drop-shadow (`feDropShadow dy=2.5 stdDeviation=7 floodColor rgba(4,13,109,0.22)`) that blends outward.
- **White track**: full circle, r=48, stroke `#FFFFFF` at 0.8 opacity, **1.5px**.
- **Blue arc**: r=48, stroke navy, **2.5px**, round cap, `strokeDasharray` for 75% starting at `rotate(135)`, with a soft glow (`feDropShadow dy=0.5 stdDeviation=4 floodColor navy 0.32`) that blends with the disk shadow.
- **Knob**: filled navy circle r=5.5 positioned at the arc's end — angle = `135 + 360 × pct` degrees (NOT × sweep). It must track the bar end for any pct.
- **Centre text**: `75%`, navy, weight 400, 19px.

### 2. Tenant Directory (`TenantDirectoryScreen`)
1. **Hero** — navy card, `250` (sky, 900, 64px) + "ACTIVE TENANTS". A **`+` button** (btn-blue, 46px circle, navy plus) overlaps the card's **bottom-right edge** (bottom: −20).
2. **Search row** — 38px top padding (clears the `+`). A grey (`#E7E6E5`) rounded search field (radius 14, height 46) with navy search icon, placeholder "Search tenants or address", a clear (✕) button when non-empty; beside it a navy 46px square button (radius 14) with a sky grid icon. **Filters the list live** by name or address; shows an empty state when nothing matches.
3. **Tenant rows** — one per tenant, grid `1.7fr / 1fr`, gap 12, row gap 14:
   - **Info card** (glass): tenant NAME (500, 14px, uppercase) · address (400, 12.5px, uppercase) · "N TENANTS" · a **StatusBox** (big). A white circular **edit (pencil) button** sits top-right (28px, zIndex above sheen).
   - **Payment card** (glass): `$amount` (900, 27px, navy) centred, "next payment" (mute, 11px), date (mute, 11px).
   - Data: John Smith / 5 Honeysuckle Lane / 4 / $650 / 31/05/26 / upcoming; Sarah Linton / 12 Ponsonby Road / 2 / $1,550 / 03/06/26 / paid; Marcus Chen / 88 Victoria Street / 6 / $2,100 / 28/05/26 / overdue; Amelia Hart / 4/22 Jervois Road / 3 / $1,800 / 05/06/26 / dueSoon.
4. **Bottom nav**, `tenants` active.

### 3. Tenant Profile / Edit (`TenantProfileScreen`)
1. **Top bar** — back button (grey circle) · "TENANT PROFILE" (navy, 600, 11px, uppercase, centred) · edit pencil (grey circle).
2. **Navy editable panel** (radius 24):
   - Header row: sky circular avatar "JS" · "HEAD TENANT" eyebrow + "John Smith" (white, 600, 21px) · an UPCOMING status chip.
   - **Subtenants dropdown** — a tappable field (`rgba(255,255,255,0.07)` bg) showing "3 subtenants" + chevron; toggling reveals a list of subtenant rows (avatar + name). The chevron rotates 180° when open.
   - **Editable fields** (2-col grid, each a `rgba(255,255,255,0.07)` block with sky uppercase label + white value): Address (wide), Rent amount, Frequency (dropdown chevron), Payment link via (wide, dropdown chevron).
3. **"ACTIVITY TIMELINE"** header.
4. **Timeline tree** — a vertical rail (2px line, `rgba(4,13,109,0.14)`) with circular nodes (white fill, 3px coloured border per status, white halo). Items top→bottom (newest first):
   - **Lead card** (the most recent event) — **sky** card (radius 16): "Rent paid" (navy, 700, 16px) + "$650 received" + date top-right; bottom row `$650` (800, 24px) + a navy circular check badge. Mirrors the reference's prominent lead card.
   - **Plain rows** — coloured status icon + title (navy, 600, 14px) + date (mute, right) + meta line (mute). Sequence: Rent link sent (blue/send) · Reminder notice sent (amber/bell) · Payment failed (red/✕) · Rent link sent.
5. **Bottom nav**, `tenants` active.

### Bottom nav (`BottomNav`, shared)
Navy pill (radius 999, height 62) floating 30px from bottom, 22px side insets, navy shadow. 5 icons evenly spaced: home, grid, terminal, chart (bar), gear. The active item sits in a `rgba(63,155,255,0.18)` pill and uses btn-blue; inactive icons are sky. All icons are filled glyphs.

---

## Glass (card surface) — IMPORTANT
Cards use a frosted-glass treatment (the `GlassCard` component + `.glass-rim` / `.glass-sheen` CSS in `tapt-app.html`). Recreate with the platform's blur/material if available:
- **Shell:** `linear-gradient(140deg, rgba(255,255,255,0.80), rgba(234,238,244,0.52) 50%, rgba(220,227,240,0.46))`, `backdrop-filter: blur(16px) saturate(130%)`, 1px `rgba(255,255,255,0.6)` border, drop shadow `0 12px 32px rgba(4,13,109,0.10)`.
- **Rim (inner highlight only):** `inset 0 1px 0 rgba(255,255,255,0.95)` + `inset 1px 1px 8px rgba(255,255,255,0.45)`. **No coloured/chromatic edge glow** (explicitly removed — do not add blue/cyan/violet rims).
- **Sheen:** a soft white diagonal band that sweeps across (~6.5s ease-in-out loop, fades in/out). Honour `prefers-reduced-motion`. Content sits above the sheen (zIndex 2).

---

## Interactions & Behavior
- **Directory search:** live filter of the tenant array on `name`/`address` substring; ✕ clears; empty state message when no matches.
- **Subtenants dropdown:** toggles an expanded list; chevron rotates with a 0.2s transition.
- **Edit / + / back / field rows:** wired as buttons; in the prototype they're visual. In production: `+` → new-tenant flow; edit pencil (directory row or top bar) → this profile/edit screen; back → directory; tapping a directory row → profile screen; field rows → respective editors/pickers (frequency, payment-link method, subtenants).
- **Glass sheen:** decorative ambient animation only.

## State Management
- `search` string (directory filter).
- `subtenantsOpen` boolean (profile dropdown).
- Production additions: selected tenant id (directory→profile nav), active tab (bottom nav), tenant list + timeline data from API, edit-form field state, dropdown selections (frequency, payment-link method).

## Assets
- **Fonts:** Outfit (`fonts/*.otf`, weights 300–900) — bundled. Use the same family or the codebase's equivalent.
- **Icons:** all inline SVG in the `G` component in `app-replica-screens.jsx` (tenants, warn, page, pause, plus, search, chevron, pencil, home, grid, terminal, chart, gear, check, x, send, bell, card, clock, cash, back). Replace with the codebase's icon set, matching shape/weight.
- No raster images.

## Files
- `app-replica-screens.jsx` — **all three screens + shared components** (the real design; read this first).
- `tapt-app.html` — entry point; holds the `@font-face` declarations and the `.glass-rim` / `.glass-sheen` keyframes/CSS.
- `ios-frame.jsx` — mock device frame (presentation only — ignore).
- `design-canvas.jsx` — pan/zoom canvas wrapper (presentation only — ignore).
- `fonts/` — Outfit font files.
