# Handoff: last 4 days of work (2026-06-21 → 2026-06-25)

This package contains all work done in the **remixed** app over the last 4 days, so
Claude on the **original** app can replay it and bring that copy up to date.

- **Baseline (what "before" means):** commit `e9a05ca` — *"chore(trades): record applied
  additive trades DDL as migration 0007"* (2026-06-17). Everything after this point is in
  this package.
- **End state:** current working tree of the remixed app (includes committed work **and**
  uncommitted work-in-progress).
- **Scope:** 45 files, ~4,855 insertions / ~475 deletions.
- **Companion file:** `last-4-days.patch` — a single unified diff of the entire change set.

---

## ⚠️ Read this first — two things that will bite you

1. **Phase 1 of the Trades vertical is NOT in this package.** The 06-21 baseline already
   contained Phase 1 (the trades DB tables, Zod schemas, storage methods, `/api/trades`
   routes, and `migrations/0007_trades_vertical.sql`), all done 2026-06-17. If the original
   app **predates the whole Trades vertical**, you must also port that Phase 1 work first or
   nothing here will compile. Quick check on the original app: does
   `migrations/0007_trades_vertical.sql` exist and do `clients` / `quotes` / `job_invoices` /
   `schedules` tables exist in `shared/schema.ts`? If **no**, port Phase 1 before applying
   this patch.

2. **Database migrations are NOT auto-applied by the patch.** This package adds two new
   migrations (0008, 0009). After applying the code you must run them against the original
   app's database. Both are written to be additive and non-destructive (ADD COLUMN IF NOT
   EXISTS / CREATE INDEX IF NOT EXISTS / reversible status updates — no DROP, no DELETE). See
   "Database changes" below.

---

## How to apply this package (on the original app)

```bash
# from the root of the original app's repo, on a fresh branch
git checkout -b port/trades-last-4-days

# dry-run first — see if it applies cleanly
git apply --stat last-4-days.patch     # shows the files it will touch
git apply --check last-4-days.patch    # verifies it applies; no changes yet

# if --check passes:
git apply last-4-days.patch

# if --check FAILS (the two codebases have diverged), fall back to a 3-way merge
# which applies what it can and leaves conflict markers for the rest:
git apply --3way last-4-days.patch
```

If `--3way` still rejects hunks, hand this `HANDOFF.md` + the relevant section of
`last-4-days.patch` to Claude on the original app and have it re-apply file-by-file. The
prose summary below is written so the work can be reconstructed even without the diff.

After the code is in: **run the migrations** (see below), then `npm run check` (tsc) and the
test suite.

---

## Database changes (run these on the original app's DB, in order)

**`migrations/0008_trades_phase3c_fixes.sql`**
- Adds `merchants.trade_reminders_enabled boolean NOT NULL DEFAULT true` — a separate on/off
  switch so disabling rent reminders doesn't silently stop trades job-invoice reminders.
- Remediates any pre-existing duplicate recurring invoices, then creates a **partial unique
  index** `job_invoices_schedule_due_uq ON (schedule_id, due_at) WHERE schedule_id IS NOT NULL
  AND status <> 'voided'` to make recurring-invoice generation idempotent. The remediation
  only voids *surplus unpaid* duplicates (reversible), never touches a paid invoice, and
  deliberately **fails loudly** if a group has 2+ paid invoices (a real double-payment that
  needs human reconciliation).

**`migrations/0009_trades_gst_mode.sql`** (supports the in-progress GST feature, below)
- `merchants.trade_gst_mode text NOT NULL DEFAULT 'inclusive'`
- `quotes.gst_mode text` (nullable; per-quote override snapshot)

> Status note carried over from the remixed app: migration 0008 had **not yet been applied**
> to the remixed app's own DB at handoff time — verify it runs cleanly when you apply here.

---

## What was done — by feature area

### A. Trades vertical — Phases 2 → 3c (the bulk of the work)

A new "Trades" merchant vertical (alongside the existing Retail/Property verticals), mirroring
the Property structure under `/trades/*`.

- **Phase 2 — nav & shells** (`b4d0d85`, `15cb5af`, `bb131f0`, `69860f7`, `be84038`)
  - `TRADES_THEME` swappable design-token block (`client/src/lib/trades-theme.ts`)
  - Page shells: dashboard, client directory, client profile, analytics, terminal
  - `/trades/*` routes registered, mirroring property
  - 3-way settings switcher (Retail · Property · Trades), responsive
- **Phase 3a — terminal & quick invoice** (`db170cb`, `89f1fe9`, `42e8bc4`)
  - `client/src/lib/trades-api.ts` fetch helpers (`tradesFetch` / `tradesHeaders`)
  - Functional terminal ported from the property terminal, scoped to `/api/trades`:
    QuickInvoice keypad → note → send; jobs home stack with status dots + outstanding
    headline; ChooseClient / MarkExternal / SentSuccess; JobActionSheet (mark received
    externally / cancel). `trades-terminal.tsx` is the big one (~960 lines).
  - Dashboard → terminal entry flow
- **Phase 3b — quote lifecycle & client workflows** (`ff208f8`, `69e37f9`)
  - Quote builder + quote response (client-facing accept/decline)
  - Recurring billing + live analytics
- **Phase 3c — cross-cutting correctness** (`62670d1`, `526a8a9`, `7b4ac6c`, `0b2f3a3`)
  - Quote delivery + invoice payment processing (`server/trades-delivery.ts`,
    `server/trades-cron.ts`)
  - Correctness fixes from review: clamp monthly recurrence to month length (no Jan-31 drift);
    dedup recurring invoices (23505 treated as skip → no double-billing); single
    `windcaveSessionId` enforced only for non-split invoices (don't 403 concurrent split
    payers); block job completion on a deposit-only invoice; send-balance requires a
    quote-linked deposit and subtracts all billed invoices; `dispatch_failed` counts as
    overdue-eligible; analytics windows collected revenue by `paidAt`; emit
    `quote_dispatch_failed` on delivery failure.
  - Hardened the recurring-dedup migration + kept `MemStorage` (dev fallback) type-correct.

### B. Email reliability (`ad79135`)
Onboarding auto-emails were **silently faking success** — both email services fall back to a
simulation that returns `true`, so a missing `RESEND_API_KEY`, unverified sender domain, or
provider error looked like a successful send.
- In **production**, report real failures instead of simulating success (dev still simulates).
- New `GET /api/admin/email-status` exposing live provider/from/admin-notify config and whether
  email will actually deliver.
- Fixed admin test-email sending from the wrong (likely-unverified) `noreply@tapt.co.nz`;
  standardised the sender env var on **`RESEND_FROM_EMAIL`** (was legacy `SENDGRID_FROM_EMAIL`
  in two places).

### C. Onboarding / signup (`be75302`)
- Signup now emails the admin (`ADMIN_EMAIL` / `ADMIN_NOTIFY_EMAIL`) **immediately** on account
  creation, so leads that abandon before KYC are still surfaced.
- Dropped the redundant mid-funnel admin email (its fields are all in the final KYC submission).
- **Removed the orphaned `/verify-merchant` page + `POST /api/verify-merchant` route** (nothing
  navigated to it; superseded by signup + `/api/auth/confirm-email`) and its references in the
  smoke/syntax tests. Live funnel unchanged: signup → confirm-email → business-details → login →
  onboarding (KYC).

### D. TypeScript / build health (`f340f7e`)
`tsc` is now clean. Two of these were **real runtime bugs**, not just type noise:
- Push routes read `req.merchantId` (always undefined → always 401); corrected to
  `req.user?.merchantId`.
- `admin-api` used the wrong `apiRequest` convention (broken at runtime); corrected to
  `apiRequest(method, url, data)`.
- Also: centralised `Window` augmentations in `client/src/global.d.ts`; `tsconfig` target →
  ES2020; added `'crypto'`/`'api'` to the transaction paymentMethod enum.

### E. Landing page (from the very start of the window)
Restore of the clean flat-navy / white sticky-card carousel design + a hero login button.
(These are early-window commits; included in the patch.)

---

## Work IN PROGRESS — not finished, not fully committed

A **GST mode setting + quote PDF export** feature was in progress at handoff. Design spec is
committed (`6845d7d`,
`docs/specs/2026-06-23-trades-gst-mode-and-quote-pdf-design.md`) and the implementation plan +
first code exist as **uncommitted/untracked** files (all captured in the patch):

- `migrations/0009_trades_gst_mode.sql` — new (see Database changes)
- `shared/trades-gst.ts` — GST calculation helpers (inclusive/exclusive modes)
- `server/trades-quote-pdf.ts` — quote PDF generation
- `scripts/smoke-quote-pdf.ts` — smoke test for PDF output
- `client/src/__tests__/trades-gst.test.ts` — GST unit tests
- `docs/superpowers/plans/2026-06-23-trades-gst-mode-and-quote-pdf.md` — the build plan
- Plus uncommitted edits to `settings.tsx`, `quote-builder.tsx`, `quote-response.tsx`,
  `routes.ts`, `schema.ts`, `email-service.ts`, `trades-delivery.ts`, `App.tsx`.

Treat this feature as **partially built** — finish it against the plan doc above rather than
assuming it's done.

---

## Full commit list (window)

```
6845d7d docs(trades): design spec — GST mode setting + quote PDF export
be75302 feat(onboarding): notify admin at signup; consolidate the dual flow
ad79135 fix(email): stop masking delivery failures; add diagnostics
f340f7e fix(types): clear all pre-existing tsc errors (tsc now clean)
526a8a9 fix(trades): harden recurring dedup migration and fix MemStorage types
62670d1 fix(trades): correctness fixes from phase 3c review
7b4ac6c feat(trades): deliver quotes and process invoice payments
0b2f3a3 fix(trades): handle empty token lookups from Neon
69e37f9 feat(trades): add recurring billing and live analytics
ff208f8 feat(trades): add quote lifecycle and client workflows
42e8bc4 feat(trades): link dashboard → terminal (dashboard-then-terminal entry)
89f1fe9 feat(trades): functional terminal + quick-invoice path
db170cb feat(trades): trades-api fetch helpers (tradesFetch/tradesHeaders)
e04b188 docs(trades): Phase 3a implementation plan — terminal & quick invoice
be84038 chore(trades): Phase 2 verification tweaks
69860f7 feat(trades): 3-way settings switcher (Retail · Property · Trades)
bb131f0 feat(trades): register /trades/* routes mirroring property
15cb5af feat(trades): page shells — dashboard, clients, profile, analytics, terminal
b4d0d85 feat(trades): TRADES_THEME swappable token block
f7398ee docs(trades): Phase 2 implementation plan — nav & shells
274846f fix(landing): restore clean flat-navy / white sticky-card carousel design
0cbdfc0 Add a login button to the main landing page hero section
```
(plus interim Replit auto-save commits, folded into the single patch.)

---

## Verification checklist for the original app after porting
- [ ] Phase 1 trades work present (migration 0007 + trades tables) — port first if missing
- [ ] `git apply --check last-4-days.patch` passes (or resolve with `--3way`)
- [ ] Run migration 0008, then 0009
- [ ] `npm run check` (tsc) is clean
- [ ] Test suite passes
- [ ] `GET /api/admin/email-status` shows email will actually deliver (set `RESEND_FROM_EMAIL`,
      verified sender domain, `RESEND_API_KEY`)
- [ ] GST mode / quote PDF feature: recognise it as WIP and finish against its plan doc
