import{f as s}from"./index-CT7j6KZb.js";/**
 * @license lucide-react v0.453.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const e=s("Minus",[["path",{d:"M5 12h14",key:"1ays0h"}]]);export{e as M};
