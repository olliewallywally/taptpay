import{l as $,r as h,u as E,d as R,j as e,a8 as O,a9 as q,aa as _}from"./index-CT7j6KZb.js";import{u as W}from"./useQuery-BMnHOoPR.js";import{p as B}from"./property-api-CTwI_r11.js";const r={navy:"#040D6D",sky:"#58AAFD",btn:"#58AAFD",white:"#FFFFFF",gray:"#D9D7D7",sheet:"#E8E8E8",row:"#F7F7F7",mute:"#8C8C8C"};function P(i){return"$"+(i/100).toLocaleString("en-NZ",{minimumFractionDigits:2,maximumFractionDigits:2})}function L(){const i=localStorage.getItem("authToken");return i?{Authorization:`Bearer ${i}`}:{}}function I(i){const o=i.currentTarget;o.classList.remove("tdir-pulse"),o.offsetWidth,o.classList.add("tdir-pulse")}function f({label:i,value:o,onChange:l,placeholder:m,required:a,type:x="text"}){return e.jsxs("div",{style:{marginBottom:14},children:[e.jsxs("div",{style:{fontSize:11,fontWeight:600,color:r.sky,letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:6},children:[i,a?" *":""]}),e.jsx("input",{type:x,value:o,onChange:y=>l(y.target.value),placeholder:m,style:{width:"100%",padding:"14px 16px",borderRadius:14,background:r.gray,border:"none",outline:"none",color:r.navy,fontSize:15,fontWeight:500,boxSizing:"border-box",fontFamily:"inherit"}})]})}function U({onClose:i,onSave:o,saving:l,saveError:m}){const[a,x]=h.useState({firstName:"",lastName:"",email:"",phone:"",propertyAddress:"",preferredChannel:"email"}),[y,S]=h.useState([]),[p,w]=h.useState({name:"",email:"",phone:""}),[j,N]=h.useState(!1),[D,A]=h.useState(!1),g=n=>s=>x(c=>({...c,[n]:s})),b=n=>s=>w(c=>({...c,[n]:s})),k=a.preferredChannel==="email"?!!a.email.trim():!!a.phone.trim(),u=a.firstName.trim()&&a.lastName.trim()&&a.propertyAddress.trim()&&k,v=()=>{A(!0),setTimeout(i,320)},F=()=>{p.name.trim()&&(S(n=>[...n,{...p}]),w({name:"",email:"",phone:""}),N(!1))},z=()=>{if(!u||l)return;const n=y.length>0?y.map(s=>{const c=[s.email,s.phone].filter(Boolean).join(", ");return c?`${s.name} (${c})`:s.name}).join(`
`):"";o({...a,coTenantsText:n})};return e.jsxs("div",{style:{position:"fixed",inset:0,zIndex:100},children:[e.jsx("style",{children:`
        @keyframes atSlideUp   { from { transform: translateY(100%); } to { transform: translateY(0); } }
        @keyframes atSlideDown { from { transform: translateY(0); } to { transform: translateY(100%); } }
        @keyframes atFdIn      { from { opacity: 0; } to { opacity: 1; } }
        @keyframes atFdOut     { from { opacity: 1; } to { opacity: 0; } }
      `}),e.jsx("div",{onClick:v,style:{position:"absolute",inset:0,background:"rgba(4,13,109,0.55)",backdropFilter:"blur(8px)",WebkitBackdropFilter:"blur(8px)",animation:D?"atFdOut 0.28s ease both":"atFdIn 0.28s ease both"}}),e.jsx("div",{style:{position:"absolute",bottom:0,left:0,right:0,display:"flex",justifyContent:"center"},children:e.jsxs("div",{style:{width:"100%",maxWidth:390,background:"#F4F4F4",borderRadius:"28px 28px 0 0",maxHeight:"92vh",overflowY:"auto",animation:D?"atSlideDown 0.32s cubic-bezier(0.4,0,0.2,1) both":"atSlideUp 0.38s cubic-bezier(0.16,1,0.3,1) both"},children:[e.jsx("div",{style:{display:"flex",justifyContent:"center",padding:"14px 0 2px"},children:e.jsx("div",{style:{width:36,height:4,borderRadius:2,background:"rgba(0,0,0,0.1)"}})}),e.jsxs("div",{style:{padding:"12px 24px 52px"},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:24},children:[e.jsx("span",{style:{fontWeight:700,fontSize:20,color:r.navy,letterSpacing:"-0.3px"},children:"add tenant"}),e.jsx("button",{onClick:v,style:{width:32,height:32,borderRadius:999,background:r.gray,border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"},children:e.jsx("svg",{width:14,height:14,viewBox:"0 0 24 24",fill:"none",stroke:r.navy,strokeWidth:"2.4",strokeLinecap:"round",children:e.jsx("path",{d:"M5 5l14 14M19 5L5 19"})})})]}),e.jsxs("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 12px"},children:[e.jsx(f,{label:"first name",value:a.firstName,onChange:g("firstName"),required:!0}),e.jsx(f,{label:"last name",value:a.lastName,onChange:g("lastName"),required:!0})]}),e.jsx(f,{label:"property address",value:a.propertyAddress,onChange:g("propertyAddress"),required:!0}),e.jsx(f,{label:"email",value:a.email,onChange:g("email"),type:"email"}),e.jsx(f,{label:"phone",value:a.phone,onChange:g("phone"),type:"tel"}),e.jsxs("div",{style:{marginBottom:24},children:[e.jsx("div",{style:{fontSize:11,fontWeight:600,color:r.sky,letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:8},children:"send rent link via"}),e.jsx("div",{style:{display:"flex",gap:8},children:["email","whatsapp","sms"].map(n=>e.jsx("button",{onClick:()=>x(s=>({...s,preferredChannel:n})),style:{flex:1,padding:"13px 0",borderRadius:14,border:"none",background:a.preferredChannel===n?r.navy:r.gray,color:a.preferredChannel===n?r.white:r.navy,fontWeight:600,fontSize:12.5,cursor:"pointer",textTransform:"uppercase",letterSpacing:"0.04em",transition:"background 0.18s, color 0.18s"},children:n},n))}),!k&&e.jsxs("div",{style:{marginTop:8,fontSize:12,color:"#C71A2A",fontWeight:500},children:["add ",a.preferredChannel==="email"?"an email address":"a phone number"," above to send via ",a.preferredChannel]})]}),e.jsxs("div",{style:{marginBottom:24},children:[e.jsx("div",{style:{fontSize:11,fontWeight:600,color:r.sky,letterSpacing:"0.1em",textTransform:"uppercase",marginBottom:10},children:"subtenants"}),y.map((n,s)=>e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10,padding:"11px 14px",marginBottom:8,borderRadius:14,background:r.gray},children:[e.jsx("div",{style:{width:30,height:30,borderRadius:999,background:r.navy,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:11,fontWeight:700,color:r.sky},children:n.name.split(" ").map(c=>c[0]).join("").slice(0,2).toUpperCase()}),e.jsxs("div",{style:{flex:1,minWidth:0},children:[e.jsx("div",{style:{fontWeight:600,fontSize:14,color:r.navy},children:n.name}),(n.email||n.phone)&&e.jsx("div",{style:{fontWeight:400,fontSize:12,color:r.mute,marginTop:1},children:[n.email,n.phone].filter(Boolean).join(" · ")})]}),e.jsx("button",{onClick:()=>S(c=>c.filter((Z,M)=>M!==s)),style:{width:26,height:26,borderRadius:999,background:"rgba(4,13,109,0.08)",border:"none",cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0},children:e.jsx("svg",{width:12,height:12,viewBox:"0 0 24 24",fill:"none",stroke:r.navy,strokeWidth:"2.4",strokeLinecap:"round",children:e.jsx("path",{d:"M5 5l14 14M19 5L5 19"})})})]},s)),e.jsxs("button",{onClick:()=>N(n=>!n),style:{width:"100%",padding:"13px 0",borderRadius:14,border:`1.5px dashed ${j?r.sky:"rgba(4,13,109,0.18)"}`,background:j?"rgba(88,171,255,0.06)":"transparent",color:r.navy,fontWeight:600,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center",gap:8,transition:"all 0.22s ease"},children:[e.jsx("svg",{width:16,height:16,viewBox:"0 0 24 24",fill:"none",stroke:r.sky,strokeWidth:"2.4",strokeLinecap:"round",children:e.jsx("path",{d:"M12 5v14M5 12h14"})}),e.jsx("span",{style:{color:r.navy},children:"add subtenant"})]}),e.jsx("div",{style:{overflow:"hidden",maxHeight:j?"320px":"0px",transition:"max-height 0.38s cubic-bezier(0.16,1,0.3,1)"},children:e.jsxs("div",{style:{paddingTop:14,display:"flex",flexDirection:"column",gap:10},children:[e.jsx(f,{label:"name",value:p.name,onChange:b("name"),required:!0}),e.jsx(f,{label:"email",value:p.email,onChange:b("email"),type:"email"}),e.jsx(f,{label:"phone",value:p.phone,onChange:b("phone"),type:"tel"}),e.jsx("button",{onClick:F,disabled:!p.name.trim(),style:{padding:"13px 0",borderRadius:14,background:p.name.trim()?r.navy:r.gray,color:p.name.trim()?r.white:r.mute,fontWeight:600,fontSize:14,border:"none",cursor:p.name.trim()?"pointer":"default",transition:"background 0.18s"},children:"confirm subtenant"})]})})]}),m&&e.jsx("div",{style:{marginBottom:16,padding:"12px 16px",borderRadius:14,background:"rgba(255,59,78,0.07)",border:"1px solid rgba(255,59,78,0.18)"},children:e.jsx("p",{style:{color:"#C71A2A",fontSize:13,fontWeight:500,margin:0},children:m})}),e.jsx("button",{onClick:z,disabled:!u||l,style:{width:"100%",padding:"18px 0",borderRadius:999,background:u&&!l?r.navy:r.gray,color:u&&!l?r.white:r.mute,fontWeight:700,fontSize:16,border:"none",cursor:u&&!l?"pointer":"default",transition:"background 0.2s, color 0.2s"},children:l?"adding…":"add tenant"})]})]})})]})}function H(i){var o,l;return`${((o=i.firstName)==null?void 0:o[0])??""}${((l=i.lastName)==null?void 0:l[0])??""}`.toUpperCase()||"?"}function Y(i){return i!=null&&i.dueAt?new Date(i.dueAt).toLocaleDateString("en-NZ",{day:"2-digit",month:"2-digit"}):""}function K({tenant:i,nextInvoice:o,onClick:l}){const m=`${i.firstName} ${i.lastName}`.trim(),a=(o==null?void 0:o.status)==="overdue";return e.jsxs("button",{type:"button",className:"tdir-row",onClick:l,children:[e.jsx("span",{className:"tdir-avatar",children:H(i)}),e.jsxs("span",{className:"tdir-copy",children:[e.jsx("span",{className:"tdir-name",children:m}),e.jsx("span",{className:"tdir-address",children:i.propertyAddress})]}),e.jsxs("span",{className:"tdir-money",children:[e.jsx("span",{children:o?P(o.amountCents):"—"}),o?e.jsxs("small",{className:a?"overdue":"",children:[a?"overdue":"next payment",e.jsx("br",{}),Y(o)]}):e.jsx("small",{children:"no invoice"})]})]})}function V(){const[,i]=$(),[o,l]=h.useState(""),[m,a]=h.useState(!1),[x,y]=h.useState(!1),[S,p]=h.useState(null),w=E(),j=h.useRef(null);h.useLayoutEffect(()=>{_()},[]);const{data:N=[],isLoading:D}=W({queryKey:["/api/property/tenants"],queryFn:()=>B("/api/property/tenants").then(t=>t.ok?t.json():[]),staleTime:6e4,retry:!1}),{data:A=[]}=W({queryKey:["/api/property/invoices"],queryFn:()=>B("/api/property/invoices").then(t=>t.ok?t.json():[]),staleTime:3e4,retry:!1}),{data:g=[]}=W({queryKey:["/api/property/tenants","archived"],queryFn:()=>B("/api/property/tenants?includeArchived=true").then(t=>t.ok?t.json():[]),select:t=>t.filter(d=>d.status==="archived"),enabled:x,staleTime:3e4,retry:!1}),b=R({mutationFn:async t=>{const d=await fetch(`/api/property/tenants/${t}/unarchive`,{method:"POST",headers:L()});if(!d.ok)throw new Error("Failed to restore");return d.json()},onSuccess:()=>{w.invalidateQueries({queryKey:["/api/property/tenants"]})}}),k=R({mutationFn:async t=>{const d=await fetch("/api/property/tenants",{method:"POST",headers:{"Content-Type":"application/json",...L()},body:JSON.stringify(t)});if(!d.ok){const C=await d.json().then(n=>n.message).catch(()=>`Error ${d.status}`);throw new Error(C)}return d.json()},onSuccess:()=>{w.invalidateQueries({queryKey:["/api/property/tenants"]}),p(null),a(!1)},onError:t=>{p((t==null?void 0:t.message)||"Failed to add tenant. The backend may not be connected yet.")}}),u=N.filter(t=>t.status!=="archived"),v=o.trim().toLowerCase(),F=u.filter(t=>!v||`${t.firstName} ${t.lastName}`.toLowerCase().includes(v)||t.propertyAddress.toLowerCase().includes(v)),z=`active tenant${u.length!==1?"s":""}`,T=t=>{const d=A.filter(s=>s.tenantProfileId===t&&s.status!=="voided");if(d.length===0)return;const C=d.find(s=>s.status==="overdue");if(C)return C;const n=d.find(s=>["dispatched","pending_dispatch","dispatch_failed"].includes(s.status));return n||[...d].sort((s,c)=>new Date(c.createdAt).getTime()-new Date(s.createdAt).getTime())[0]};return e.jsx("div",{style:{background:r.white,minHeight:"100svh",display:"flex",justifyContent:"center"},children:e.jsxs("div",{style:{width:"100%",maxWidth:369,minHeight:"100svh",background:r.sheet,paddingBottom:128,fontFamily:"'Outfit', system-ui, sans-serif",overflow:"hidden"},children:[e.jsx("style",{children:Q}),e.jsxs("section",{ref:j,className:"pt-hero tdir-hero",children:[e.jsx("div",{className:"tdir-hero-count",children:u.length}),e.jsx("div",{className:"tdir-hero-label",children:z})]}),e.jsxs("main",{className:"tdir-body",children:[e.jsx("button",{type:"button",className:"tdir-add",onPointerDown:I,onClick:()=>a(!0),"aria-label":"Add tenant",children:e.jsx("svg",{width:26,height:26,viewBox:"0 0 24 24",fill:"none",stroke:r.navy,strokeWidth:"2.6",strokeLinecap:"round",children:e.jsx("path",{d:"M12 5v14M5 12h14"})})}),e.jsxs("div",{className:"tdir-search-row",children:[e.jsxs("label",{className:"tdir-search",children:[e.jsx("input",{value:o,onChange:t=>l(t.target.value),placeholder:"search tenants or address"}),o&&e.jsx("button",{type:"button",onClick:()=>l(""),"aria-label":"Clear search",children:e.jsx("svg",{width:15,height:15,viewBox:"0 0 24 24",fill:"none",stroke:r.mute,strokeWidth:"2.2",strokeLinecap:"round",children:e.jsx("path",{d:"M6 6l12 12M18 6 6 18"})})})]}),e.jsx("button",{type:"button",onClick:()=>O(()=>i("/property"),{expectHero:!1}),"aria-label":"Go to property dashboard",className:"tdir-grid-btn",children:e.jsxs("svg",{width:17,height:17,viewBox:"0 0 20 20",fill:r.sky,children:[e.jsx("rect",{x:"1",y:"1",width:"7",height:"7",rx:"1.5"}),e.jsx("rect",{x:"12",y:"1",width:"7",height:"7",rx:"1.5"}),e.jsx("rect",{x:"1",y:"12",width:"7",height:"7",rx:"1.5"}),e.jsx("rect",{x:"12",y:"12",width:"7",height:"7",rx:"1.5"})]})})]}),e.jsx("div",{className:"tdir-list",children:D?e.jsx("div",{className:"tdir-empty",children:"loading tenants..."}):F.length===0?e.jsx("div",{className:"tdir-empty",children:o?`no tenants match "${o}"`:"no tenants yet - tap + to add your first"}):F.map(t=>e.jsx(K,{tenant:t,nextInvoice:T(t.id),onClick:()=>{const d=T(t.id);q({id:t.id,firstName:t.firstName,lastName:t.lastName,propertyAddress:t.propertyAddress,preferredChannel:t.preferredChannel,invoiceStatus:d==null?void 0:d.status},()=>i(`/property/tenants/${t.id}`))}},t.id))}),e.jsxs("div",{className:"tdir-archived",children:[e.jsx("button",{type:"button",onClick:()=>y(t=>!t),children:x?"hide archived":"show archived"}),x&&(g.length===0?e.jsx("div",{className:"tdir-archived-empty",children:"no archived tenants"}):e.jsx("div",{className:"tdir-archived-list",children:g.map(t=>e.jsxs("div",{className:"tdir-archive-row",children:[e.jsxs("div",{children:[e.jsxs("strong",{children:[t.firstName," ",t.lastName]}),e.jsx("span",{children:t.propertyAddress})]}),e.jsx("button",{type:"button",onClick:()=>b.mutate(t.id),disabled:b.isPending,children:"restore"})]},t.id))}))]})]}),m&&e.jsx(U,{onClose:()=>{a(!1),p(null)},onSave:t=>{p(null),k.mutate(t)},saving:k.isPending,saveError:S})]})})}const Q=`
.tdir-hero {
  position: relative;
  height: 265px;
  background: #040D6D;
  color: #58AAFD;
  padding: 78px 34px 0;
  box-sizing: border-box;
}
.tdir-hero-count {
  font-family: 'Outfit', system-ui, sans-serif;
  font-size: 100px;
  line-height: 0.85;
  font-weight: 800;
  letter-spacing: 0;
  font-variant-numeric: tabular-nums;
}
.tdir-hero-label {
  margin-top: 16px;
  font-size: 13px;
  line-height: 1;
  font-weight: 600;
  letter-spacing: 0.07em;
  text-transform: uppercase;
}
.tdir-add {
  position: absolute;
  left: 50%;
  top: -34px;
  width: 68px;
  height: 68px;
  transform: translateX(-50%);
  border: none;
  border-radius: 999px;
  background: #58AAFD;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  box-shadow: 0 6px 16px rgba(4,13,109,0.16);
  -webkit-tap-highlight-color: transparent;
}
.tdir-add::after {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  pointer-events: none;
  box-shadow: 0 0 0 0 rgba(88,170,253,0);
}
.tdir-add.tdir-pulse::after {
  animation: tdirAddRing 0.48s ease-out;
}
@keyframes tdirAddRing {
  0% { box-shadow: 0 0 0 0 rgba(88,170,253,0.48); }
  100% { box-shadow: 0 0 0 10px rgba(88,170,253,0); }
}
.tdir-body {
  position: relative;
  background: #E8E8E8;
  margin-top: -28px;
  border-radius: 28px 28px 0 0;
  min-height: calc(100svh - 237px);
  padding: 50px 13px 0;
  box-sizing: border-box;
}
.tdir-search-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 40px;
  gap: 8px;
  align-items: center;
}
.tdir-search {
  height: 40px;
  border-radius: 999px;
  background: #D9D7D7;
  display: flex;
  align-items: center;
  gap: 9px;
  padding: 0 18px;
  box-sizing: border-box;
}
.tdir-search input {
  min-width: 0;
  flex: 1;
  border: none;
  outline: none;
  background: transparent;
  color: #040D6D;
  font-family: inherit;
  font-size: 13.5px;
  font-weight: 500;
  letter-spacing: 0;
}
.tdir-search input::placeholder { color: rgba(4,13,109,0.4); }
.tdir-search button {
  border: none;
  background: transparent;
  padding: 0;
  display: flex;
  cursor: pointer;
}
.tdir-grid-btn {
  width: 40px;
  height: 40px;
  border: none;
  border-radius: 13px;
  background: #040D6D;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.tdir-list {
  display: flex;
  flex-direction: column;
  padding-top: 12px;
}
.tdir-row {
  width: 100%;
  border: none;
  background: transparent;
  display: grid;
  grid-template-columns: 46px minmax(0, 1fr) auto;
  align-items: center;
  gap: 15px;
  padding: 15px 4px;
  box-sizing: border-box;
  color: #040D6D;
  font-family: inherit;
  text-align: left;
  cursor: pointer;
  -webkit-tap-highlight-color: transparent;
}
.tdir-row:active { transform: scale(0.99); opacity: 0.75; }
.tdir-avatar {
  width: 46px;
  height: 46px;
  border-radius: 999px;
  background: transparent;
  border: 1.5px solid #58AAFD;
  color: #040D6D;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 800;
  font-size: 13px;
  letter-spacing: 0.02em;
  flex-shrink: 0;
  box-sizing: border-box;
}
.tdir-copy {
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 3px;
}
.tdir-name {
  color: #040D6D;
  font-weight: 700;
  font-size: 15px;
  line-height: 1.15;
  text-transform: lowercase;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.tdir-address {
  color: rgba(4,13,109,0.75);
  font-weight: 500;
  font-size: 13.5px;
  line-height: 1.2;
  text-transform: lowercase;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.tdir-money {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  min-width: 76px;
  color: #040D6D;
  justify-self: end;
}
.tdir-money span {
  font-size: 17px;
  line-height: 1;
  font-weight: 800;
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.tdir-money small {
  font-size: 10px;
  line-height: 1.35;
  color: rgba(4,13,109,0.75);
  font-weight: 500;
  text-align: center;
  white-space: nowrap;
}
.tdir-money small.overdue { color: #C71A2A; font-weight: 700; }
.tdir-empty {
  padding: 34px 18px;
  color: rgba(4,13,109,0.55);
  text-align: center;
  font-size: 13px;
  font-weight: 600;
}
.tdir-archived {
  padding: 23px 2px 0;
}
.tdir-archived > button {
  border: none;
  background: transparent;
  color: rgba(4,13,109,0.48);
  font-family: inherit;
  font-size: 11px;
  font-weight: 850;
  cursor: pointer;
  text-transform: uppercase;
  letter-spacing: 0.08em;
  padding: 0;
}
.tdir-archived-empty {
  padding: 14px 0;
  color: rgba(4,13,109,0.48);
  font-size: 13px;
  font-weight: 650;
}
.tdir-archived-list {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 12px;
}
.tdir-archive-row {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
  border-radius: 18px;
  background: #D9D7D7;
}
.tdir-archive-row div {
  min-width: 0;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 3px;
}
.tdir-archive-row strong {
  color: #040D6D;
  font-size: 13px;
  font-weight: 850;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.tdir-archive-row span {
  color: rgba(4,13,109,0.55);
  font-size: 11px;
  font-weight: 700;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.tdir-archive-row button {
  border: none;
  border-radius: 11px;
  background: #040D6D;
  color: #FFFFFF;
  padding: 8px 13px;
  font-family: inherit;
  font-size: 12px;
  font-weight: 850;
  cursor: pointer;
}
@media (max-width: 350px) {
  .tdir-body { padding-left: 10px; padding-right: 10px; }
  .tdir-row { grid-template-columns: 42px minmax(0, 1fr) auto; gap: 10px; padding-left: 2px; padding-right: 2px; }
  .tdir-avatar { width: 42px; height: 42px; }
  .tdir-money { min-width: 68px; }
  .tdir-money span { font-size: 15px; }
}
`;export{V as default};
