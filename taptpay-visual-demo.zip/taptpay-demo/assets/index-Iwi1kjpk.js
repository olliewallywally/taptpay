import{as as i}from"./index-CT7j6KZb.js";const s=i("PushNotifications",{});export{s as PushNotifications};
